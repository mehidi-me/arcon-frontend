exports.id = 847;
exports.ids = [847];
exports.modules = {

/***/ 3887:
/***/ ((module) => {

// Exports
module.exports = {
	"projectImage": "styles_projectImage__jnq7I",
	"projectContainer": "styles_projectContainer__y8YLj",
	"hoverOverlay": "styles_hoverOverlay__h55Nf",
	"detailsContainer": "styles_detailsContainer__cB_yA"
};


/***/ }),

/***/ 6245:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mW": () => (/* binding */ getProjects),
/* harmony export */   "TR": () => (/* binding */ getSingleProject),
/* harmony export */   "tM": () => (/* binding */ getPaginateProjects)
/* harmony export */ });
/* unused harmony export getProjectsByCategoryId */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const getProjects = async ()=>{
    const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get('/projects');
    return data;
};
const getSingleProject = async (id)=>{
    const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/projects/${id}`);
    return data;
};
const getProjectsByCategoryId = async (categoryId)=>{
    const { data  } = await axios.get(`/projects/category/${categoryId}`);
    return data;
};
const getPaginateProjects = async ({ pageParam =1  })=>{
    const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get('/projects?page=' + pageParam);
    return data;
};


/***/ }),

/***/ 3097:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Wn": () => (/* binding */ ProjectDescription),
/* harmony export */   "ur": () => (/* binding */ ProjectDetails),
/* harmony export */   "XR": () => (/* binding */ ProjectContainer),
/* harmony export */   "vV": () => (/* binding */ ProjectName)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9830);



const ProjectDescription = (0,_mui_system__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(()=>({
        marginBottom: 2,
        display: 'block',
        paddingTop: 1,
        fontSize: 14,
        color: 'rgba(255,255,255,.70)',
        wordSpacing: 3,
        letterSpacing: 2
    })
);
const ProjectDetails = (0,_mui_system__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(()=>({
        height: '100%',
        color: 'white',
        position: 'relative'
    })
);
const ProjectContainer = (0,_mui_system__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(()=>({
        margin: '1rem',
        position: 'relative',
        display: 'inline-block'
    })
);
const ProjectName = (0,_mui_system__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(({ theme  })=>({
        my: 3,
        cursor: 'pointer',
        color: '#fff',
        fontWeight: 700,
        fontSize: 22,
        '&:hover': {
            color: _utils_constants__WEBPACK_IMPORTED_MODULE_2__/* .SECONDARY_COLOR */ .Vz
        }
    })
);


/***/ })

};
;