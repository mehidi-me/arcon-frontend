"use strict";
exports.id = 133;
exports.ids = [133];
exports.modules = {

/***/ 8133:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "iI": () => (/* binding */ OrangeBtn),
/* harmony export */   "YV": () => (/* binding */ ReadMoreBtn),
/* harmony export */   "Iz": () => (/* binding */ ProjectBtn),
/* harmony export */   "ej": () => (/* binding */ WhiteBtn)
/* harmony export */ });
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5574);
/* harmony import */ var _mui_material_colors__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_colors__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9830);




const OrangeBtn = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_0___default()))(()=>({
        backgroundColor: _utils_constants__WEBPACK_IMPORTED_MODULE_3__/* .SECONDARY_COLOR */ .Vz,
        color: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.grey[900],
        fontWeight: 700,
        padding: '8px 20px',
        variant: 'contained',
        textTransform: 'uppercase',
        borderRadius: '50px',
        ':hover': {
            backgroundColor: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.grey[50],
            color: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.grey[900]
        }
    })
);
const ReadMoreBtn = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_0___default()))(()=>({
        color: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.blueGrey[900],
        fontWeight: 700,
        textTransform: 'uppercase',
        ':hover': {
            color: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.blueGrey[900],
            backgroundColor: 'none'
        }
    })
);
// project section read more button
const ProjectBtn = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_0___default()))(()=>({
        color: 'white',
        '&:hover': {
            color: _utils_constants__WEBPACK_IMPORTED_MODULE_3__/* .SECONDARY_COLOR */ .Vz
        }
    })
);
const WhiteBtn = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_0___default()))(()=>({
        color: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.grey[50],
        fontWeight: 700,
        variant: 'outlined',
        borderRadius: '50px',
        padding: '8px 20px',
        border: '1px solid white',
        position: 'relative',
        textTransform: 'uppercase',
        ':hover': {
            color: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.grey[900],
            backgroundColor: _utils_constants__WEBPACK_IMPORTED_MODULE_3__/* .SECONDARY_COLOR */ .Vz,
            border: '1px solid ' + _utils_constants__WEBPACK_IMPORTED_MODULE_3__/* .SECONDARY_COLOR */ .Vz
        }
    })
);


/***/ }),

/***/ 9830:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Vz": () => (/* binding */ SECONDARY_COLOR),
/* harmony export */   "cE": () => (/* binding */ DANGER_COLOR),
/* harmony export */   "lx": () => (/* binding */ DANGER_COLOR_DARK),
/* harmony export */   "AX": () => (/* binding */ TERTIARY_COLOR)
/* harmony export */ });
/* unused harmony export API_URL */
const SECONDARY_COLOR = '#FAE80C';
const DANGER_COLOR = '#FF0000';
const DANGER_COLOR_DARK = '#ff2400';
const API_URL = (/* unused pure expression or super */ null && ("https://api.arconinterior.com.bd"));
const TERTIARY_COLOR = '#F3C430';


/***/ })

};
;