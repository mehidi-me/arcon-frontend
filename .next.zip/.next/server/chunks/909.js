"use strict";
exports.id = 909;
exports.ids = [909];
exports.modules = {

/***/ 3909:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ CreateProjectComp),
  "U": () => (/* binding */ sunEditorCommonProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/lab"
var lab_ = __webpack_require__(6072);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(1175);
// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(9755);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(5609);
// EXTERNAL MODULE: ./recoil/atoms/dialogsAtom.ts
var dialogsAtom = __webpack_require__(9659);
// EXTERNAL MODULE: ./recoil/atoms/mediaAtom.ts
var mediaAtom = __webpack_require__(7266);
// EXTERNAL MODULE: ./components/admin/media/ImagePreview.tsx
var ImagePreview = __webpack_require__(1896);
// EXTERNAL MODULE: ./components/common/Dialog/UploadImageDialog.tsx
var UploadImageDialog = __webpack_require__(1494);
// EXTERNAL MODULE: ./recoil/atoms/userAtom.ts
var userAtom = __webpack_require__(8793);
;// CONCATENATED MODULE: ./components/admin/create/createProjectHooks.ts




const createProjectHooks = (router)=>{
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const User = (0,external_recoil_.useRecoilValue)(userAtom/* userAtom */.L);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const newProjectMutation = (0,external_react_query_.useMutation)(async (newProject)=>{
        const { title , featureImg , challenges , clients , description , ideas , category , location , name , projectImgs , workingYear ,  } = newProject;
        return external_axios_default().post('/projects/create', {
            title,
            name,
            description,
            location,
            workingYear,
            clients,
            category,
            ideas,
            challenges,
            featureImg,
            images: projectImgs,
            userId: User._id
        });
    }, {
        onSuccess: ()=>{
            router.push('/admin');
        }
    });
    return {
        newProjectMutation
    };
};

;// CONCATENATED MODULE: ./components/admin/create/style.ts
const createFormStyle = {
    overflow: 'hidden',
    '& .se-placeholder': {
        fontSize: '1.2 rem'
    }
};

;// CONCATENATED MODULE: ./components/admin/create/index.tsx


















const SunEditor = (0,dynamic["default"])(()=>Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 5594, 23))
, {
    loadableGenerated: {
        webpack: ()=>[
                /*require.resolve*/(5594)
            ]
        ,
        modules: [
            "../components/admin/create/index.tsx -> " + "suneditor-react"
        ]
    },
    ssr: false
});
const sunEditorCommonProps = {
    setDefaultStyle: 'font-size: 1.2rem;',
    setOptions: {
        buttonList: [
            [
                'undo',
                'redo'
            ],
            [
                'paragraphStyle',
                'blockquote'
            ],
            [
                'bold',
                'underline',
                'italic',
                'strike',
                'subscript',
                'superscript'
            ],
            [
                'removeFormat'
            ],
            [
                'link'
            ], 
        ]
    }
};
const validationSchema = external_yup_.object().shape({
    title: external_yup_.string().min(2).required('Title is required'),
    name: external_yup_.string().min(2).required('Name is required'),
    description: external_yup_.string().min(2).required('Description is required'),
    category: external_yup_.string().required('Category is required'),
    clients: external_yup_.string().min(2).required('Clients is required'),
    location: external_yup_.string().min(2).required('Location is required'),
    workingYear: external_yup_.string().min(4).required('Working year is required'),
    ideas: external_yup_.string().min(2).required('Ideas is required'),
    challenges: external_yup_.string().min(2).required('Challenges is required'),
    featureImg: external_yup_.mixed().required('Feature image is required'),
    projectImgs: external_yup_.mixed().required('Project images are required. Maximum 3')
});
function CreateProjectComp() {
    const { data: categories  } = (0,external_react_query_.useQuery)('categories', async ()=>{
        const { data  } = await external_axios_default().get('/categories');
        return data;
    });
    const router = (0,router_.useRouter)();
    const { newProjectMutation  } = createProjectHooks(router);
    const { errors , values: values1 , touched , setFieldValue , handleSubmit , handleChange  } = (0,external_formik_.useFormik)({
        initialValues: {
            title: '',
            name: '',
            description: '',
            clients: '',
            location: '',
            workingYear: '',
            ideas: '',
            category: '',
            challenges: '',
            featureImg: [],
            projectImgs: []
        },
        validationSchema,
        onSubmit: (values)=>{
            newProjectMutation.mutate(values);
        }
    });
    const handleTextEditorChange = (field, value)=>{
        setFieldValue(field, value, true);
    };
    const { 0: featureImgDialog , 1: setFeatureImgDialog  } = (0,external_react_.useState)(false);
    const { 0: projectImgsDialog , 1: setProjectImgsDialog  } = (0,external_react_.useState)(false);
    const [selectedImages, setSelectedImages] = (0,external_recoil_.useRecoilState)(mediaAtom/* selectedImagesAtom */.p);
    // this state is for showing previews
    const featuredImgSrc = (0,external_recoil_.useRecoilValue)(dialogsAtom/* featuredImgSrcAtom */.V0);
    const projectImgsSrc = (0,external_recoil_.useRecoilValue)(dialogsAtom/* projectImgsSrcAtom */.a9);
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
        maxWidth: "md",
        sx: {
            my: 8
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
            onSubmit: handleSubmit,
            component: "form",
            sx: createFormStyle,
            encType: "multipart/form-data",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                        name: "title",
                        label: "Project Title",
                        variant: "outlined",
                        fullWidth: true,
                        value: values1.title,
                        onChange: handleChange,
                        error: touched.title && Boolean(errors.title),
                        helperText: touched.title && errors.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                        name: "name",
                        label: "Project Name",
                        variant: "outlined",
                        fullWidth: true,
                        value: values1.name,
                        onChange: handleChange,
                        error: touched.name && Boolean(errors.name),
                        helperText: touched.name && errors.name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                        name: "description",
                        label: "Project Description",
                        variant: "outlined",
                        fullWidth: true,
                        multiline: true,
                        minRows: 3,
                        value: values1.description,
                        onChange: handleChange,
                        error: touched.description && Boolean(errors.description),
                        helperText: touched.description && errors.description
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                        name: "clients",
                        label: "Clients",
                        variant: "outlined",
                        fullWidth: true,
                        value: values1.clients,
                        onChange: handleChange,
                        error: touched.clients && Boolean(errors.clients),
                        helperText: touched.clients && errors.clients
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                        name: "location",
                        label: "Location",
                        variant: "outlined",
                        fullWidth: true,
                        value: values1.location,
                        onChange: handleChange,
                        error: touched.location && Boolean(errors.location),
                        helperText: touched.location && errors.location
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                        name: "workingYear",
                        label: `Working Year (i.e., ${new Date().getFullYear()})`,
                        variant: "outlined",
                        fullWidth: true,
                        value: values1.workingYear,
                        onChange: handleChange,
                        error: touched.workingYear && Boolean(errors.workingYear),
                        helperText: touched.workingYear && errors.workingYear
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Select, {
                        labelId: "category",
                        variant: 'outlined',
                        id: "category",
                        name: "category",
                        displayEmpty: true,
                        value: values1.category,
                        label: "Category",
                        onChange: handleChange,
                        error: touched.category && Boolean(errors.category),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                                value: '',
                                children: "Choose Category"
                            }),
                            categories === null || categories === void 0 ? void 0 : categories.map((category)=>{
                                const id = category._id;
                                return(/*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                                    value: id,
                                    children: category.title
                                }, id));
                            })
                        ]
                    }),
                    touched.category && Boolean(errors.category) && /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        color: 'red',
                        sx: {
                            fontSize: '12px'
                        },
                        variant: 'h6',
                        children: errors.category
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        htmlFor: "feature_img",
                        children: "Feature Image"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                        onClick: ()=>setFeatureImgDialog(true)
                        ,
                        children: "Upload Feature Image"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(UploadImageDialog/* UploadImageDialog */.S, {
                        operation: "create",
                        open: featureImgDialog,
                        handleClose: ()=>{
                            setFeatureImgDialog(false);
                            setSelectedImages([]);
                        },
                        title: "Upload Featured Image",
                        onCompleteSelected: ()=>{
                            setFieldValue('featureImg', selectedImages);
                            setSelectedImages([]);
                            setFeatureImgDialog(false);
                        },
                        allowMultiple: false,
                        imageType: "featuredImg"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ImagePreview/* ImagePreview */.e, {
                        imgsSrc: featuredImgSrc
                    }),
                    touched.featureImg && /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        variant: "body2",
                        color: "error",
                        children: errors.featureImg
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        htmlFor: "project_imgs",
                        children: "Project Images(Max: 3)"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                        onClick: ()=>setProjectImgsDialog(true)
                        ,
                        children: "Upload Project Images"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(UploadImageDialog/* UploadImageDialog */.S, {
                        operation: "create",
                        open: projectImgsDialog,
                        handleClose: ()=>{
                            setProjectImgsDialog(false);
                            setSelectedImages([]);
                        },
                        title: "Upload Project Images",
                        onCompleteSelected: ()=>{
                            setFieldValue('projectImgs', selectedImages);
                            setSelectedImages([]);
                            setProjectImgsDialog(false);
                        },
                        imageType: "projectImgs"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ImagePreview/* ImagePreview */.e, {
                        imgsSrc: projectImgsSrc
                    }),
                    touched.projectImgs && /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        variant: "body2",
                        color: "error",
                        children: errors.projectImgs
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                variant: "h5",
                                children: "Ideas:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(SunEditor, {
                                name: "ideas",
                                ...sunEditorCommonProps,
                                onChange: (content)=>handleTextEditorChange('ideas', content)
                            })
                        ]
                    }),
                    touched.ideas && /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        variant: "body2",
                        color: "error",
                        children: errors.ideas
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                variant: "h5",
                                children: "Challenges:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(SunEditor, {
                                name: "challenges",
                                onChange: (content)=>handleTextEditorChange('challenges', content)
                                ,
                                ...sunEditorCommonProps
                            })
                        ]
                    }),
                    touched.challenges && /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        variant: "body2",
                        color: "error",
                        children: errors.challenges
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(lab_.LoadingButton, {
                        type: "submit",
                        color: "secondary",
                        variant: "contained",
                        sx: {
                            color: 'white'
                        },
                        loading: newProjectMutation.isLoading,
                        children: "Create"
                    })
                ]
            })
        })
    }));
};


/***/ }),

/***/ 1896:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ ImagePreview)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);



const ImagePreview = ({ imgsSrc  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        container: true,
        spacing: 2,
        justifyContent: "center",
        alignItems: "center",
        children: imgsSrc.length > 0 && imgsSrc.map((img)=>{
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                sx: {
                    height: '100px',
                    width: '100%'
                },
                item: true,
                lg: 3,
                position: "relative",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    layout: "fill",
                    objectFit: "contain",
                    src: img,
                    alt: "Projects Image"
                })
            }, img));
        })
    }));
};


/***/ }),

/***/ 1494:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ UploadImageDialog)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _admin_media__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5161);



const UploadImageDialog = ({ open , handleClose , title , operation , onCompleteSelected , allowMultiple , imageType ,  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Dialog, {
        fullWidth: true,
        maxWidth: "xl",
        onClose: handleClose,
        open: open,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogTitle, {
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_admin_media__WEBPACK_IMPORTED_MODULE_2__/* .MediaLibraryContent */ .U, {
                operation: operation,
                limit: 12,
                onCompleteSelected: onCompleteSelected,
                allowMultiple: allowMultiple,
                imageType: imageType
            })
        ]
    }));
};


/***/ })

};
;