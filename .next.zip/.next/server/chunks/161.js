"use strict";
exports.id = 161;
exports.ids = [161];
exports.modules = {

/***/ 5161:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "U": () => (/* binding */ MediaLibraryContent)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/icons-material/Add"
var Add_ = __webpack_require__(6146);
var Add_default = /*#__PURE__*/__webpack_require__.n(Add_);
// EXTERNAL MODULE: external "@mui/icons-material/Delete"
var Delete_ = __webpack_require__(3188);
var Delete_default = /*#__PURE__*/__webpack_require__.n(Delete_);
// EXTERNAL MODULE: external "@mui/icons-material/Save"
var Save_ = __webpack_require__(9932);
var Save_default = /*#__PURE__*/__webpack_require__.n(Save_);
// EXTERNAL MODULE: external "@mui/icons-material/UploadFile"
var UploadFile_ = __webpack_require__(9747);
var UploadFile_default = /*#__PURE__*/__webpack_require__.n(UploadFile_);
// EXTERNAL MODULE: external "@mui/lab"
var lab_ = __webpack_require__(6072);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "filepond-plugin-image-exif-orientation"
var external_filepond_plugin_image_exif_orientation_ = __webpack_require__(1711);
var external_filepond_plugin_image_exif_orientation_default = /*#__PURE__*/__webpack_require__.n(external_filepond_plugin_image_exif_orientation_);
// EXTERNAL MODULE: external "filepond-plugin-image-preview"
var external_filepond_plugin_image_preview_ = __webpack_require__(8984);
var external_filepond_plugin_image_preview_default = /*#__PURE__*/__webpack_require__.n(external_filepond_plugin_image_preview_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-filepond"
var external_react_filepond_ = __webpack_require__(5178);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(1175);
// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(9755);
// EXTERNAL MODULE: ./hooks/useIntersectionObserver.ts
var useIntersectionObserver = __webpack_require__(3398);
// EXTERNAL MODULE: ./recoil/atoms/dialogsAtom.ts
var dialogsAtom = __webpack_require__(9659);
// EXTERNAL MODULE: ./recoil/atoms/mediaAtom.ts
var mediaAtom = __webpack_require__(7266);
// EXTERNAL MODULE: ./utils/constants.ts
var constants = __webpack_require__(9830);
// EXTERNAL MODULE: ./components/common/Button/index.tsx
var Button = __webpack_require__(8133);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./utils/functions.ts
const isElementExistsInArray = (arr, value)=>{
    let result = false;
    for(let i = 0; i < arr.length; i++){
        if (arr[i] === value) {
            result = true;
            break;
        }
    }
    return result;
};
const deleteAnElementFromTheArray = (arr, value)=>arr.filter((item)=>item !== value
    )
;

// EXTERNAL MODULE: ./components/common/Dialog/index.tsx + 1 modules
var Dialog = __webpack_require__(3036);
;// CONCATENATED MODULE: ./components/admin/media/SingleImage.tsx











const SingleImage = ({ img: img1 , refetch , operation , allowMultiple , imageType ,  })=>{
    // Controlling dialog
    const [isDialogOpen, setIsDialogOpen] = (0,external_recoil_.useRecoilState)(dialogsAtom/* deleteImagesDialogAtom */.Hu);
    const handleDialogClose = ()=>{
        setIsDialogOpen(false);
    };
    const [selectedImages, setSelectedImages] = (0,external_recoil_.useRecoilState)(mediaAtom/* selectedImagesAtom */.p);
    const [featuredImgSrc, setFeaturedImgSrc] = (0,external_recoil_.useRecoilState)(dialogsAtom/* featuredImgSrcAtom */.V0);
    const [projectImgsSrc, setProjectImgsSrc] = (0,external_recoil_.useRecoilState)(dialogsAtom/* projectImgsSrcAtom */.a9);
    const imgSrcLen = (0,external_recoil_.useRecoilValue)(dialogsAtom/* getProjectImgsSrcLengthSelector */.FO);
    (0,external_react_.useEffect)(()=>{
        setProjectImgsSrc([]);
    }, []);
    const handleChange = (keyOrId, url)=>{
        if (imageType === 'featuredImg') {
            setFeaturedImgSrc([
                url
            ]);
        }
        if (imageType === 'projectImgs') {
            if (isElementExistsInArray(projectImgsSrc, url)) {
                setProjectImgsSrc(deleteAnElementFromTheArray(projectImgsSrc, url));
            } else {
                let arr = projectImgsSrc;
                if (projectImgsSrc.length >= 3) {
                    arr = projectImgsSrc.slice(1);
                }
                setProjectImgsSrc([
                    ...arr,
                    url
                ]);
            }
        }
        // if allowMultiple is false,
        // override the existing array
        if (!allowMultiple) {
            setSelectedImages([
                ...[],
                keyOrId
            ]);
            return;
        }
        if (isElementExistsInArray(selectedImages, keyOrId)) {
            setSelectedImages(deleteAnElementFromTheArray(selectedImages, keyOrId));
        } else {
            let arr = selectedImages;
            if (selectedImages.length >= 3) {
                arr = selectedImages.slice(1);
            }
            setSelectedImages([
                ...arr,
                keyOrId
            ]);
        }
    };
    const { 0: isLoading , 1: setIsLoading  } = (0,external_react_.useState)(false);
    const deleteSelectedImages = async ()=>{
        let url = '/media/images';
        selectedImages.forEach((img, index)=>{
            // returns something like ?image=some_image_key&image=another_image_key
            if (index === 0) {
                url += '?';
            } else {
                url += '&';
            }
            url += 'imageKeys=' + img;
        });
        setIsLoading(true);
        try {
            await external_axios_default()["delete"](url);
            await refetch();
            setSelectedImages([]);
        } catch (e) {
            console.log(e);
        } finally{
            setIsLoading(false);
        }
    };
    const { _id: id , fileName , url: url1 , key  } = img1;
    // checking whether the image is selected or not to apply backdrop
    let checked = isElementExistsInArray(selectedImages, id);
    if (operation === 'delete') {
        checked = isElementExistsInArray(selectedImages, key);
    }
    // getting the index to show on top of the image
    const selectedImageNo = operation === 'delete' ? selectedImages.indexOf(key) + 1 : selectedImages.indexOf(id) + 1;
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
        item: true,
        lg: 2,
        md: 3,
        sm: 4,
        xs: 6,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
            height: 150,
            width: "100%",
            position: 'relative',
            onClick: ()=>{
                if (operation === 'delete') {
                    handleChange(key, url1);
                } else {
                    handleChange(id, url1);
                }
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    src: url1,
                    layout: 'fill',
                    alt: fileName
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        display: checked ? 'flex' : 'none',
                        position: 'absolute',
                        top: 0,
                        right: 0,
                        width: '100%',
                        height: 150,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: 'rgba(0, 0, 0, 0.6)'
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        sx: {
                            fontSize: 30,
                            fontWeight: 600,
                            color: 'white'
                        },
                        children: selectedImageNo
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Dialog/* default */.Z, {
                    open: isDialogOpen,
                    onClose: handleDialogClose,
                    modalTitle: "Are you sure you want to delete this?",
                    modalDesc: "Please confirm before you delete this image. You won't be able to retrieve this image once you deleted it.",
                    closeButtonTitle: "Yes, Go Ahead",
                    onYes: async ()=>deleteSelectedImages()
                    ,
                    closeButton: true,
                    backgroundColor: constants/* DANGER_COLOR */.cE,
                    isLoading: isLoading
                })
            ]
        })
    }, id));
};

;// CONCATENATED MODULE: ./components/admin/media/style.ts

const adminMediaContainer = {
    marginX: 'auto',
    marginY: 5,
    height: '100%',
    width: '80%'
};
const imgActionBtn = {
    position: 'fixed',
    bottom: {
        xs: 16,
        md: 20,
        lg: 40
    },
    color: 'black'
};
const addImageActionBtn = {
    ...imgActionBtn,
    right: {
        xs: 16,
        md: 20,
        lg: 40
    }
};
const deleteImageActionBtn = {
    ...imgActionBtn,
    right: {
        xs: 125,
        md: 120,
        lg: 150
    },
    backgroundColor: constants/* DANGER_COLOR */.cE,
    color: 'white',
    '&:hover': {
        backgroundColor: constants/* DANGER_COLOR_DARK */.lx
    }
};
const createImageActionBtn = {
    ...imgActionBtn,
    right: {
        xs: 140,
        md: 145,
        lg: 150
    },
    backgroundColor: constants/* TERTIARY_COLOR */.AX,
    color: 'black',
    '&:hover': {
        backgroundColor: constants/* TERTIARY_COLOR */.AX
    }
};
const mediaImageList = {
    //   maxWidth: 700,
    //   height: "75vh",
    margin: 'auto',
    overflow: 'hidden',
    width: '100%',
    height: '100%'
};

;// CONCATENATED MODULE: ./components/admin/media/index.tsx








// Import the Image EXIF Orientation and Image Preview plugins



// Import FilePond styles












// Register the plugins
(0,external_react_filepond_.registerPlugin)((external_filepond_plugin_image_exif_orientation_default()), (external_filepond_plugin_image_preview_default()));
const MediaLibraryContent = ({ limit , operation , onCompleteSelected , allowMultiple =true , imageType ,  })=>{
    const { data: data1 , isLoading , refetch , isFetchingNextPage , fetchNextPage , hasNextPage  } = (0,external_react_query_.useInfiniteQuery)([
        'all-images'
    ], async ({ pageParam =1  })=>{
        let url = '/media/images?page=' + pageParam;
        if (limit) {
            url += '&limit=' + limit;
        }
        const { data  } = await external_axios_default().get(url);
        return data;
    }, {
        getNextPageParam: (lastPage)=>lastPage.nextPage ?? false
    });
    const selectedImages = (0,external_recoil_.useRecoilValue)(mediaAtom/* selectedImagesAtom */.p);
    const imagesLength = selectedImages.length;
    const [, setDeleteImagesDialog] = (0,external_recoil_.useRecoilState)(dialogsAtom/* deleteImagesDialogAtom */.Hu);
    const [addImagesDialog, setAddImagesDialog] = (0,external_recoil_.useRecoilState)(dialogsAtom/* addImagesDialogAtom */.OI);
    const { 0: files , 1: setFiles  } = (0,external_react_.useState)([]);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const uploadImages = async ()=>{
        const data = new FormData();
        const images = Array.from(files);
        images.forEach((file)=>data.append('images', file.source)
        );
        setLoading(true);
        try {
            await external_axios_default()({
                method: 'POST',
                url: '/media/upload/images',
                data,
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            setAddImagesDialog(false);
            setFiles([]);
            await refetch();
        } catch (e) {
            console.log(e.response);
        } finally{
            setLoading(false);
        }
    };
    // for infinity scrolling
    const loadMoreButtonRef = (0,external_react_.useRef)(null);
    (0,useIntersectionObserver/* default */.Z)({
        target: loadMoreButtonRef,
        onIntersect: ()=>fetchNextPage()
        ,
        enabled: hasNextPage
    });
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: adminMediaContainer,
        children: [
            isLoading && /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    p: 4
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.CircularProgress, {
                    color: "secondary"
                })
            }),
            (data1 === null || data1 === void 0 ? void 0 : data1.pages) && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        container: true,
                        sx: mediaImageList,
                        spacing: {
                            xs: 2,
                            md: 3
                        },
                        alignItems: "center",
                        justifyContent: "center",
                        children: data1.pages.map((page)=>{
                            return page.images.map((img)=>{
                                return(/*#__PURE__*/ jsx_runtime_.jsx(SingleImage, {
                                    allowMultiple: allowMultiple,
                                    operation: operation,
                                    img: img,
                                    refetch: refetch,
                                    imageType: imageType
                                }, img._id));
                            });
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* OrangeBtn */.iI, {
                        sx: {
                            my: 5,
                            display: 'block',
                            mx: 'auto'
                        },
                        disabled: !hasNextPage,
                        ref: loadMoreButtonRef,
                        onClick: ()=>fetchNextPage()
                        ,
                        children: isFetchingNextPage ? 'Loading more...' : hasNextPage ? 'Load More' : 'Nothing more to load'
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Fab, {
                onClick: ()=>setAddImagesDialog(true)
                ,
                variant: "extended",
                sx: addImageActionBtn,
                color: "secondary",
                "aria-label": "add",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Add_default()), {
                        sx: {
                            color: 'black'
                        }
                    }),
                    "Add"
                ]
            }),
            imagesLength > 0 && operation === 'delete' ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Fab, {
                variant: "extended",
                sx: deleteImageActionBtn,
                "aria-label": "delete",
                onClick: ()=>setDeleteImagesDialog(true)
                ,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Delete_default()), {
                        sx: {
                            color: 'white'
                        }
                    }),
                    "Delete (",
                    imagesLength,
                    " selected)"
                ]
            }) : imagesLength > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Fab, {
                variant: "extended",
                sx: createImageActionBtn,
                "aria-label": "create",
                onClick: ()=>{
                    if (onCompleteSelected) {
                        onCompleteSelected();
                    }
                // if (imageType === 'featuredImg') {
                //   setFeatureImgSrc([URL.createObjectURL(files[0])]);
                // }
                // if (imageType === 'projectImgs') {
                //   let arr: string[] = [];
                //   files.forEach((file: any) => {
                //     arr.push(URL.createObjectURL(file));
                //   });
                //   setProjectImgsSrc(arr);
                // }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Save_default()), {
                        sx: {
                            color: 'black',
                            mr: 2
                        }
                    }),
                    `Select ${imagesLength} images`
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Dialog, {
                fullWidth: true,
                maxWidth: "md",
                onClose: ()=>setAddImagesDialog(false)
                ,
                open: addImagesDialog,
                sx: {
                    py: 5
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.DialogTitle, {
                        children: "Upload Image"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_filepond_.FilePond, {
                        files: files,
                        onupdatefiles: setFiles,
                        allowMultiple: true,
                        maxFiles: 4,
                        name: "files",
                        labelIdle: "Drag & Drop your files or <span class=\"filepond--label-action\">Browse</span>"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.DialogActions, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lab_.LoadingButton, {
                            sx: {
                                backgroundColor: constants/* SECONDARY_COLOR */.Vz,
                                borderRadius: '50px',
                                color: 'white',
                                px: 5,
                                my: 2,
                                mr: 2,
                                '&:hover': {
                                    backgroundColor: constants/* SECONDARY_COLOR */.Vz
                                }
                            },
                            loadingIndicator: /*#__PURE__*/ jsx_runtime_.jsx(material_.CircularProgress, {
                                color: 'secondary',
                                size: 16
                            }),
                            disabled: loading,
                            loadingPosition: "start",
                            startIcon: /*#__PURE__*/ jsx_runtime_.jsx((UploadFile_default()), {
                            }),
                            loading: loading,
                            variant: "contained",
                            autoFocus: true,
                            onClick: uploadImages,
                            children: "Upload Images"
                        })
                    })
                ]
            })
        ]
    }));
};


/***/ }),

/***/ 3398:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useIntersectionObserver)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useIntersectionObserver({ root , target , onIntersect , threshold =1 , rootMargin ='0px' , enabled =true  }) {
    react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(()=>{
        if (!enabled) {
            return;
        }
        const observer = new IntersectionObserver((entries)=>entries.forEach((entry)=>entry.isIntersecting && onIntersect()
            )
        , {
            root: root && root.current,
            rootMargin,
            threshold
        });
        const el = target && target.current;
        if (!el) {
            return;
        }
        observer.observe(el);
        return ()=>{
            observer.unobserve(el);
        };
    }, [
        enabled,
        root,
        rootMargin,
        threshold,
        target,
        onIntersect
    ]);
};


/***/ }),

/***/ 9659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hu": () => (/* binding */ deleteImagesDialogAtom),
/* harmony export */   "OI": () => (/* binding */ addImagesDialogAtom),
/* harmony export */   "V0": () => (/* binding */ featuredImgSrcAtom),
/* harmony export */   "a9": () => (/* binding */ projectImgsSrcAtom),
/* harmony export */   "FO": () => (/* binding */ getProjectImgsSrcLengthSelector)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const deleteImagesDialogAtom = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: 'delete-image-dialog',
    default: false
});
const addImagesDialogAtom = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: 'add-image-dialog',
    default: false
});
const featuredImgSrcAtom = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: 'feature-img-src',
    default: []
});
const projectImgsSrcAtom = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: 'project-imgs-src',
    default: []
});
const getProjectImgsSrcLengthSelector = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.selector)({
    key: 'get-project-imgs-src-length',
    get: ({ get  })=>{
        const arr = get(projectImgsSrcAtom);
        return arr.length;
    }
});


/***/ }),

/***/ 7266:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ selectedImagesAtom)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const selectedImagesAtom = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: 'media-atom',
    default: []
});


/***/ })

};
;