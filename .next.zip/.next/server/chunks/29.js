exports.id = 29;
exports.ids = [29];
exports.modules = {

/***/ 5649:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "styles_container__yseSy"
};


/***/ }),

/***/ 2029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(7986);
// EXTERNAL MODULE: external "@mui/icons-material/Home"
var Home_ = __webpack_require__(3467);
var Home_default = /*#__PURE__*/__webpack_require__.n(Home_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/material/Breadcrumbs"
var Breadcrumbs_ = __webpack_require__(7185);
var Breadcrumbs_default = /*#__PURE__*/__webpack_require__.n(Breadcrumbs_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./utils/constants.ts
var constants = __webpack_require__(9830);
;// CONCATENATED MODULE: ./components/common/breadcrumb/index.tsx







function Breadcrumb({ pageTitle  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
        sx: {
            backgroundColor: '#fff',
            p: 1,
            width: 'fit-content',
            position: 'absolute',
            bottom: 0,
            left: '7%',
            pr: 2
        },
        role: "presentation",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Breadcrumbs_default()), {
            "aria-label": "breadcrumb",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                    display: "flex",
                    alignItems: 'center',
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Home_default()), {
                            sx: {
                                mr: 1
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/",
                            children: "Home"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    color: constants/* SECONDARY_COLOR */.Vz,
                    children: pageTitle
                })
            ]
        })
    }));
};

// EXTERNAL MODULE: ./components/common/navbar/index.tsx + 2 modules
var navbar = __webpack_require__(35);
// EXTERNAL MODULE: ./components/common/Title/index.tsx
var Title = __webpack_require__(4353);
// EXTERNAL MODULE: ./components/common/header/styles.module.css
var styles_module = __webpack_require__(5649);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
;// CONCATENATED MODULE: ./components/common/header/index.tsx







function Header({ breadcrumbTitle , pageTitle  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (styles_module_default()).container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(navbar/* default */.Z, {
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(system_.Box, {
                component: "header",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Title/* PageTitle */.V1, {
                        position: "relative",
                        top: "150px",
                        variant: "h3",
                        children: pageTitle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumb, {
                        pageTitle: breadcrumbTitle
                    })
                ]
            })
        ]
    }));
};


/***/ })

};
;