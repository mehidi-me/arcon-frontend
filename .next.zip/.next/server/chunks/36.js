"use strict";
exports.id = 36;
exports.ids = [36];
exports.modules = {

/***/ 3036:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ CustomizedDialogs)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/icons-material/Close"
var Close_ = __webpack_require__(4173);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
// EXTERNAL MODULE: external "@mui/icons-material/Delete"
var Delete_ = __webpack_require__(3188);
var Delete_default = /*#__PURE__*/__webpack_require__.n(Delete_);
// EXTERNAL MODULE: external "@mui/lab"
var lab_ = __webpack_require__(6072);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/material/DialogActions"
var DialogActions_ = __webpack_require__(9404);
var DialogActions_default = /*#__PURE__*/__webpack_require__.n(DialogActions_);
// EXTERNAL MODULE: external "@mui/material/DialogContent"
var DialogContent_ = __webpack_require__(1094);
var DialogContent_default = /*#__PURE__*/__webpack_require__.n(DialogContent_);
// EXTERNAL MODULE: external "@mui/material/DialogTitle"
var DialogTitle_ = __webpack_require__(2468);
var DialogTitle_default = /*#__PURE__*/__webpack_require__.n(DialogTitle_);
// EXTERNAL MODULE: external "@mui/material/IconButton"
var IconButton_ = __webpack_require__(7934);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./utils/constants.ts
var constants = __webpack_require__(9830);
// EXTERNAL MODULE: external "@mui/material/Dialog"
var Dialog_ = __webpack_require__(8611);
var Dialog_default = /*#__PURE__*/__webpack_require__.n(Dialog_);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
;// CONCATENATED MODULE: ./components/common/Dialog/style.ts


const BootstrapDialog = (0,styles_.styled)((Dialog_default()))(({ theme  })=>({
        '& .MuiDialogContent-root': {
            padding: theme.spacing(2)
        },
        '& .MuiDialog-paperScrollPaper': {
            padding: theme.spacing(3),
            [theme.breakpoints.down('sm')]: {
                padding: theme.spacing(1)
            }
        },
        '& .MuiDialogActions-root': {
            padding: theme.spacing(1)
        }
    })
);

;// CONCATENATED MODULE: ./components/common/Dialog/index.tsx












const BootstrapDialogTitle = (props)=>{
    const { children , onClose , ...other } = props;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)((DialogTitle_default()), {
        sx: {
            m: 0,
            p: 2,
            fontSize: {
                xs: 20,
                sm: 30
            }
        },
        ...other,
        children: [
            children,
            onClose ? /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                "aria-label": "close",
                onClick: onClose,
                sx: {
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme)=>theme.palette.grey[500]
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {
                })
            }) : null
        ]
    }));
};
function CustomizedDialogs({ open , modalTitle , modalDesc , onClose , onYes , closeButtonTitle , closeButton =false , backgroundColor =constants/* SECONDARY_COLOR */.Vz , isLoading =false  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(BootstrapDialog, {
            color: constants/* SECONDARY_COLOR */.Vz,
            onClose: onClose,
            "aria-labelledby": "customized-dialog-title",
            open: open,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(BootstrapDialogTitle, {
                    id: "customized-dialog-title",
                    onClose: onClose,
                    children: modalTitle
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((DialogContent_default()), {
                    dividers: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        gutterBottom: true,
                        children: modalDesc
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((DialogActions_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(lab_.LoadingButton, {
                            sx: {
                                marginTop: 2,
                                backgroundColor,
                                borderRadius: '50px',
                                color: 'white',
                                px: 5,
                                '&:hover': {
                                    backgroundColor
                                }
                            },
                            loadingIndicator: /*#__PURE__*/ jsx_runtime_.jsx(material_.CircularProgress, {
                                color: 'secondary',
                                size: 16
                            }),
                            disabled: isLoading,
                            loadingPosition: "start",
                            startIcon: /*#__PURE__*/ jsx_runtime_.jsx((Delete_default()), {
                            }),
                            loading: isLoading,
                            variant: "contained",
                            autoFocus: true,
                            onClick: async ()=>{
                                // run the http request here
                                onYes && await onYes();
                                // close the dialog
                                onClose();
                            },
                            children: closeButtonTitle
                        }),
                        closeButton && /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                            sx: {
                                marginTop: 2,
                                color: 'gray'
                            },
                            onClick: ()=>onClose()
                            ,
                            children: "Not Now"
                        })
                    ]
                })
            ]
        })
    }));
};


/***/ })

};
;