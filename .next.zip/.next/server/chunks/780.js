exports.id = 780;
exports.ids = [780];
exports.modules = {

/***/ 5447:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "styles_container__yM4wC",
	"schedule": "styles_schedule__kYudG",
	"infoDiv": "styles_infoDiv__m9iH2",
	"flexDiv": "styles_flexDiv__vPypX"
};


/***/ }),

/***/ 2350:
/***/ ((module) => {

// Exports
module.exports = {
	"itemContainer": "styles_itemContainer__TsPZJ",
	"active": "styles_active__c9XNZ"
};


/***/ }),

/***/ 2205:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "s1": () => (/* binding */ Facebook),
  "mr": () => (/* binding */ Instagram),
  "yh": () => (/* binding */ LinkedIn),
  "nz": () => (/* binding */ Pinterest)
});

// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(7986);
// EXTERNAL MODULE: external "@mui/icons-material/Facebook"
var Facebook_ = __webpack_require__(7666);
var Facebook_default = /*#__PURE__*/__webpack_require__.n(Facebook_);
// EXTERNAL MODULE: external "@mui/icons-material/Instagram"
var Instagram_ = __webpack_require__(3281);
var Instagram_default = /*#__PURE__*/__webpack_require__.n(Instagram_);
// EXTERNAL MODULE: external "@mui/icons-material/LinkedIn"
var LinkedIn_ = __webpack_require__(5939);
var LinkedIn_default = /*#__PURE__*/__webpack_require__.n(LinkedIn_);
// EXTERNAL MODULE: external "@mui/icons-material/Pinterest"
var Pinterest_ = __webpack_require__(5941);
var Pinterest_default = /*#__PURE__*/__webpack_require__.n(Pinterest_);
// EXTERNAL MODULE: external "@mui/material/colors"
var colors_ = __webpack_require__(5574);
// EXTERNAL MODULE: ./utils/constants.ts
var constants = __webpack_require__(9830);
;// CONCATENATED MODULE: ./components/common/SocialIcon/style.ts


const commonIcon = {
    fontSize: '2rem',
    padding: '5px',
    margin: '5px',
    color: '#cbcbcb',
    boxShadow: '0px 0px 2px 0px grey',
    cursor: 'pointer',
    borderRadius: '5px',
    ':hover': {
        backgroundColor: constants/* SECONDARY_COLOR */.Vz,
        color: colors_.grey[50],
        boxShadow: 'none'
    }
};

;// CONCATENATED MODULE: ./components/common/SocialIcon/index.tsx






const Facebook = (0,system_.styled)((Facebook_default()))(()=>({
        ...commonIcon
    })
);
const Instagram = (0,system_.styled)((Instagram_default()))(()=>({
        ...commonIcon
    })
);
const LinkedIn = (0,system_.styled)((LinkedIn_default()))(()=>({
        ...commonIcon
    })
);
const Pinterest = (0,system_.styled)((Pinterest_default()))(()=>({
        ...commonIcon
    })
);


/***/ }),

/***/ 4353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NZ": () => (/* binding */ SectionTitle),
/* harmony export */   "Dx": () => (/* binding */ Title),
/* harmony export */   "k3": () => (/* binding */ BarTitle),
/* harmony export */   "V1": () => (/* binding */ PageTitle),
/* harmony export */   "Gh": () => (/* binding */ HeaderTitle),
/* harmony export */   "dk": () => (/* binding */ Description),
/* harmony export */   "$t": () => (/* binding */ Percentage)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5574);
/* harmony import */ var _mui_material_colors__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_colors__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9830);




const SectionTitle = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(()=>({
        color: _utils_constants__WEBPACK_IMPORTED_MODULE_3__/* .TERTIARY_COLOR */ .AX,
        fontWeight: 500,
        position: 'relative',
        textTransform: 'uppercase'
    })
);
const Title = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(()=>({
        fontWeight: 700,
        textAlign: 'center'
    })
);
const BarTitle = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(()=>({
        fontWeight: 600,
        marginBottom: 2
    })
);
const PageTitle = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(()=>({
        fontWeight: 700,
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-end',
        height: 100,
        color: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.grey[50]
    })
);
const HeaderTitle = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(()=>({
        fontWeight: 700,
        color: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.grey[50],
        position: 'relative',
        margin: '10px 0px 10px 0px'
    })
);
const Description = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(()=>({
        fontWeight: 400,
        lineHeight: '27px',
        letterSpacing: '0.3px',
        color: '#777777',
        component: 'p'
    })
);
const Percentage = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(()=>({
        fontWeight: 700,
        position: 'absolute',
        left: '78%',
        bottom: 30,
        variant: 'body1'
    })
);


/***/ }),

/***/ 6371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/icons-material/AccessTimeFilled"
var AccessTimeFilled_ = __webpack_require__(7541);
var AccessTimeFilled_default = /*#__PURE__*/__webpack_require__.n(AccessTimeFilled_);
// EXTERNAL MODULE: external "@mui/icons-material/Call"
var Call_ = __webpack_require__(2081);
var Call_default = /*#__PURE__*/__webpack_require__.n(Call_);
// EXTERNAL MODULE: external "@mui/icons-material/Email"
var Email_ = __webpack_require__(9226);
var Email_default = /*#__PURE__*/__webpack_require__.n(Email_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./utils/constants.ts
var constants = __webpack_require__(9830);
// EXTERNAL MODULE: ./components/common/Button/index.tsx
var Button = __webpack_require__(8133);
// EXTERNAL MODULE: ./components/common/SocialIcon/index.tsx + 1 modules
var SocialIcon = __webpack_require__(2205);
// EXTERNAL MODULE: ./components/common/Title/index.tsx
var Title = __webpack_require__(4353);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/common/footer/footerCol.tsx




function FooterCol(props) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        mt: "2rem",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                variant: "h6",
                sx: {
                    color: '#fff'
                },
                children: props.menuTitle ? props.menuTitle : ' '
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                spacing: 2,
                component: "ul",
                sx: {
                    listStyle: 'none',
                    pl: 0
                },
                children: props.menuItems.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                        component: "li",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: item.link,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: item.name
                            })
                        })
                    }, index)
                )
            })
        ]
    }));
};

;// CONCATENATED MODULE: ./components/common/footer/muiTooltip.tsx


const BootstrapTooltip = (0,material_.styled)(({ className , ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Tooltip, {
        ...props,
        arrow: true,
        classes: {
            popper: className
        }
    })
)(({ theme  })=>({
        [`& .${material_.tooltipClasses.arrow}`]: {
            color: theme.palette.common.black
        },
        [`& .${material_.tooltipClasses.tooltip}`]: {
            backgroundColor: theme.palette.common.black
        }
    })
);

// EXTERNAL MODULE: ./components/common/footer/styles.module.css
var styles_module = __webpack_require__(5447);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
;// CONCATENATED MODULE: ./components/common/footer/index.tsx















function Footer() {
    const router = (0,router_.useRouter)();
    const QuickLinks = [
        {
            name: 'Make Appointments',
            link: '/appointment'
        },
        {
            name: 'Before & After',
            link: '/#'
        },
        {
            name: 'Customer Treatments',
            link: '/#'
        },
        {
            name: 'Our Special Team',
            link: '/#'
        },
        {
            name: 'Departments Services',
            link: '/#'
        },
        {
            name: 'About our Firm',
            link: '/#'
        },
        {
            name: 'Contact Us',
            link: '/contact'
        },
        {
            name: 'Privacy Policy',
            link: '/privacy'
        }, 
    ];
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        className: (styles_module_default()).container,
        sx: {
            marginTop: {
                xs: 5,
                sm: 7,
                md: 13
            }
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
            sx: {
                color: '#fff'
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        container: true,
                        spacing: 6,
                        sx: {
                            mt: 4,
                            '& .MuiSvgIcon-root': {
                                fontSize: '3.2rem',
                                backgroundColor: constants/* SECONDARY_COLOR */.Vz,
                                padding: '12px',
                                marginX: '10px',
                                borderRadius: '5px'
                            }
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                item: true,
                                lg: 4,
                                className: (styles_module_default()).infoDiv,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Call_default()), {
                                        sx: {
                                            color: '#212121'
                                        }
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                variant: "h6",
                                                sx: {
                                                    fontWeight: 700,
                                                    fontSize: '18px'
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "tel: +8801687266144",
                                                    children: "+8801687266144"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                children: "Have a question? call us now"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                item: true,
                                lg: 4,
                                className: (styles_module_default()).infoDiv,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Email_default()), {
                                        sx: {
                                            color: '#212121'
                                        }
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                variant: "h6",
                                                sx: {
                                                    fontWeight: 700,
                                                    fontSize: '18px'
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "mailto:arconconsultancybd@gmail.com",
                                                    children: "arconconsultancybd@gmail.com"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                children: "Need support? Drop us an email"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                item: true,
                                lg: 4,
                                className: (styles_module_default()).infoDiv,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((AccessTimeFilled_default()), {
                                        sx: {
                                            color: '#212121'
                                        }
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                                variant: "h6",
                                                sx: {
                                                    fontWeight: 700,
                                                    fontSize: '18px'
                                                },
                                                children: [
                                                    ' ',
                                                    "Mon – Sat 07:00 – 21:00"
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                children: "We are open on"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        boxShadow: '0px 0px 1px grey',
                        width: 'unset'
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            container: true,
                            sx: {
                                mt: 10,
                                justifyContent: 'space-between'
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                    item: true,
                                    md: 3,
                                    sm: 6,
                                    xs: 12,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(FooterCol, {
                                        menuTitle: "Quick Links",
                                        menuItems: QuickLinks
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                    item: true,
                                    md: 5,
                                    sm: 6,
                                    xs: 12,
                                    textAlign: "center",
                                    sx: {
                                        boxShadow: '0px 0px 1px 0px grey',
                                        p: 5,
                                        alignItems: 'center'
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                            sx: {
                                                cursor: 'pointer'
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                onClick: ()=>router.push('/')
                                                ,
                                                src: "/images/logo.svg",
                                                alt: "logo",
                                                width: 120,
                                                height: 120
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                            spacing: 1,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Title/* Description */.dk, {
                                                    children: "Arcon design consultancy firm that brings sensitivity to the design top hotels, offices & homes around the world."
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "/about",
                                                    passHref: true,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* ReadMoreBtn */.YV, {
                                                        sx: {
                                                            color: '#FAE80C',
                                                            '&:hover': {
                                                                color: '#FAE80C'
                                                            }
                                                        },
                                                        children: "Read More"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    variant: "h6",
                                                    children: "Address: "
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    sx: {
                                                        fontSize: {
                                                            xs: 14,
                                                            md: 16,
                                                            lg: 18
                                                        }
                                                    },
                                                    children: "Nasirabad Housing Society, Flot -1"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    sx: {
                                                        fontSize: {
                                                            xs: 14,
                                                            md: 16,
                                                            lg: 18
                                                        }
                                                    },
                                                    children: "Zakir Hossain Road, Rose Valley, Khulshi, Chittagong"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                    sx: {
                                        color: 'rgba(255,255,255,.65)'
                                    },
                                    item: true,
                                    md: 3,
                                    sm: 12,
                                    xs: 12,
                                    my: "2rem",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                            spacing: 2,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    sx: {
                                                        color: '#fff'
                                                    },
                                                    component: "h6",
                                                    variant: "h6",
                                                    children: "Our Time Schedule"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                    className: (styles_module_default()).schedule,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                                            children: "Mon to Wed"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                                            children: "10:00 am to 2:30 pm"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                    className: (styles_module_default()).schedule,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                                            children: "Thu to Fri"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                                            children: "11:00 am to 4:30 pm"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                    className: (styles_module_default()).schedule,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                                            children: "Saturday"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                                            children: "10:00 am to 1:00 pm"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                    className: (styles_module_default()).schedule,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                                            children: "Sunday"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                                            children: "Closed"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                            sx: {
                                                mt: 5
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Title/* Title */.Dx, {
                                                    variant: "h6",
                                                    children: " Follow Us On"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                                    sx: {
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        justifyContent: 'center',
                                                        alignItems: 'center'
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(BootstrapTooltip, {
                                                            title: "Facebook",
                                                            placement: "top",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                href: "https://www.facebook.com/arcon.interior/",
                                                                target: "_blank",
                                                                rel: "noreferrer",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* Facebook */.s1, {
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(BootstrapTooltip, {
                                                            title: "Instagram",
                                                            placement: "top",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                href: "https://www.instagram.com/arcon_interiors/",
                                                                target: "_blank",
                                                                rel: "noreferrer",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* Instagram */.mr, {
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(BootstrapTooltip, {
                                                            title: "Linkedin",
                                                            placement: "top",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                href: "https://www.linkedin.com/home/",
                                                                target: "_blank",
                                                                rel: "noreferrer",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* LinkedIn */.yh, {
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(BootstrapTooltip, {
                                                            title: "Pinterest",
                                                            placement: "top",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                href: "https://www.pinterest.com/",
                                                                target: "_blank",
                                                                rel: "noreferrer",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* Pinterest */.nz, {
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                    sx: {
                        my: 5
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                            flexWrap: "wrap",
                            display: "flex",
                            justifyContent: "center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                    sx: {
                                        color: 'background.paper',
                                        fontSize: {
                                            xs: '13px',
                                            sm: '16px'
                                        }
                                    },
                                    children: [
                                        "Copyright \xa9 ",
                                        new Date().getFullYear(),
                                        " Arcon Interior by \xa0"
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    sx: {
                                        fontSize: {
                                            xs: '13px',
                                            sm: '16px'
                                        }
                                    },
                                    color: "secondary",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        target: "_blank",
                                        href: "https://zorgitgroup.com",
                                        rel: "noreferrer",
                                        children: "Zorg IT Group"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                            component: "ul",
                            sx: {
                                display: 'flex',
                                justifyContent: 'center',
                                flexDirection: 'row',
                                pl: 0,
                                fontSize: {
                                    xs: '13px',
                                    sm: '16px'
                                }
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                    component: "li",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/about",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "About Us \xa0 "
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: " | "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                    component: "li",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/#services",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "\xa0 Services \xa0"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: " | "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                                    component: "li",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "\xa0 Privacy"
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};


/***/ }),

/***/ 35:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Navbar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowUp"
var KeyboardArrowUp_ = __webpack_require__(9881);
var KeyboardArrowUp_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowUp_);
// EXTERNAL MODULE: external "@mui/icons-material/PhoneInTalkOutlined"
var PhoneInTalkOutlined_ = __webpack_require__(6113);
var PhoneInTalkOutlined_default = /*#__PURE__*/__webpack_require__.n(PhoneInTalkOutlined_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/material/CssBaseline"
var CssBaseline_ = __webpack_require__(4960);
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_);
// EXTERNAL MODULE: external "@mui/material/Fab"
var Fab_ = __webpack_require__(3661);
var Fab_default = /*#__PURE__*/__webpack_require__.n(Fab_);
// EXTERNAL MODULE: external "@mui/material/useScrollTrigger"
var useScrollTrigger_ = __webpack_require__(4156);
var useScrollTrigger_default = /*#__PURE__*/__webpack_require__.n(useScrollTrigger_);
// EXTERNAL MODULE: external "@mui/material/Zoom"
var Zoom_ = __webpack_require__(1528);
var Zoom_default = /*#__PURE__*/__webpack_require__.n(Zoom_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./utils/constants.ts
var constants = __webpack_require__(9830);
// EXTERNAL MODULE: external "@mui/material/Popover"
var Popover_ = __webpack_require__(5768);
var Popover_default = /*#__PURE__*/__webpack_require__.n(Popover_);
// EXTERNAL MODULE: external "@mui/icons-material"
var icons_material_ = __webpack_require__(7915);
// EXTERNAL MODULE: external "@mui/icons-material/Close"
var Close_ = __webpack_require__(4173);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
;// CONCATENATED MODULE: ./components/common/navbar/styles.ts

const logo = {
    flexGrow: 1,
    cursor: 'pointer'
};
const navStyles = {
    boxShadow: 'none',
    height: '80px',
    top: 0,
    zIndex: 999,
    position: 'fixed'
};
const activeItem = {
    color: 'yellow'
};
const navLinks = {
    display: {
        xs: 'none',
        md: 'flex'
    },
    gap: {
        md: 4
    },
    height: '80px',
    margin: 0,
    listStyle: 'none',
    textTransform: 'uppercase',
    cursor: 'pointer',
    fontWeight: 600,
    flexWrap: 'nowrap',
    '& .MuiTypography-root': {
        fontSize: '14px',
        fontWeight: 500
    },
    '& .MuiListItem-root': {
        width: 'unset'
    }
};
const icon = {
    fontSize: '40px',
    color: '#fff',
    outline: 'none'
};
const mbLink = {
    '& .MuiTypography-root': {
        fontSize: '16px',
        fontWeight: 600
    },
    '&:hover': {
        color: constants/* SECONDARY_COLOR */.Vz
    }
}; // export const itemHover: muiSxPropType = {
 //   height: '100%',
 //   borderTop: '4px solid transparent',
 //   '&:hover': {
 //     borderWidth: '100%',
 //     borderTop: '4px solid #ff6f00',
 //     transition: 'all .5s ease-in-out',
 //   },
 // };
 /* export const phoneSvg: muiSxPropType = {
  fill: 'red',
  border: '1px solid orange',
}; */ 

;// CONCATENATED MODULE: ./components/common/navbar/mobileNav.tsx








function MobileNav() {
    const [anchorEl, setAnchorEl] = external_react_.useState(null);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            display: {
                xs: 'block',
                md: 'none'
            }
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                "aria-describedby": id,
                onClick: handleClick,
                children: open ? /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {
                    sx: icon
                }) : /*#__PURE__*/ jsx_runtime_.jsx(icons_material_.MenuOutlined, {
                    sx: icon
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Popover_default()), {
                sx: {
                    '& .MuiPopover-paper': {
                        position: 'relative',
                        justifyContent: 'center'
                    }
                },
                id: id,
                open: open,
                anchorEl: anchorEl,
                onClose: handleClose,
                anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'left'
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                            sx: mbLink,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: "Home"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                            sx: mbLink,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/about",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: "About Us"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                            sx: mbLink,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: {
                                    pathname: '/',
                                    hash: 'services'
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: "Services"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                            sx: mbLink,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/projects",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: "Projects"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                            sx: mbLink,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: {
                                    pathname: '/',
                                    hash: 'contact'
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: "Contact Us"
                                })
                            })
                        })
                    })
                ]
            })
        ]
    }));
};

// EXTERNAL MODULE: ./components/common/navbar/styles.module.css
var styles_module = __webpack_require__(2350);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
;// CONCATENATED MODULE: ./components/common/navbar/index.tsx
















function ScrollTop(props) {
    const { children , window , elRef  } = props;
    // Note that you normally won't need to set the window ref as useScrollTrigger
    // will default to window.
    // This is only being set here because the demo is in an iframe.
    const trigger = useScrollTrigger_default()({
        target: window ? window() : undefined,
        disableHysteresis: true,
        threshold: 100
    });
    const handleClick = (event)=>{
        const anchor = elRef.current;
        if (anchor) {
            anchor.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
        }
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx((Zoom_default()), {
        in: trigger,
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
            onClick: handleClick,
            role: "presentation",
            sx: {
                position: 'fixed',
                bottom: 16,
                right: 16,
                zIndex: 10
            },
            children: children
        })
    }));
}
function Navbar() {
    // transparent navbar
    const [navbar, setNavbar] = external_react_.useState(false);
    const backToTopAnchor = external_react_.useRef(null);
    const ChangeBackground = ()=>{
        if (window.scrollY >= 80) {
            setNavbar(true);
        } else {
            setNavbar(false);
        }
    };
    if (false) {}
    const router = (0,router_.useRouter)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CssBaseline_default()), {
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                component: "header",
                ref: backToTopAnchor,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.AppBar, {
                    sx: navbar ? {
                        background: 'rgb(24,24,24,0.81)',
                        ...navStyles
                    } : {
                        background: 'transparent',
                        ...navStyles
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Toolbar, {
                            id: "back-to-top-anchor",
                            sx: {
                                ml: {
                                    lg: '80px'
                                }
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                    sx: logo,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                src: "/images/logo.svg",
                                                alt: "logo",
                                                width: 120,
                                                height: 120
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(MobileNav, {
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                            container: true,
                                            sx: navLinks,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                                                    className: (styles_module_default()).itemContainer,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                                        className: (router === null || router === void 0 ? void 0 : router.asPath) == '/' ? (styles_module_default()).active : '',
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                            href: "/",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                children: "Home"
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                                                    className: (styles_module_default()).itemContainer,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                                        className: (router === null || router === void 0 ? void 0 : router.asPath) == '/about' ? (styles_module_default()).active : '',
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                            href: "/about",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                children: "About Us"
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                                                    className: (styles_module_default()).itemContainer,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                                        className: (router === null || router === void 0 ? void 0 : router.asPath) == '/#services' ? (styles_module_default()).active : '',
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                            href: "/#services",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                children: "Services"
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                                                    className: (styles_module_default()).itemContainer,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                                        className: (router === null || router === void 0 ? void 0 : router.asPath) == '/projects' ? (styles_module_default()).active : '',
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                            href: "/projects",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                children: "Projects"
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItem, {
                                                    className: (styles_module_default()).itemContainer,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                                        className: (router === null || router === void 0 ? void 0 : router.asPath) == '/#contact' ? (styles_module_default()).active : '',
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                            href: "/#contact",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                children: "Contact Us"
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                        sx: {
                                                            display: 'flex',
                                                            mt: 1
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                                sx: {
                                                                    display: 'flex',
                                                                    justifyContent: 'center',
                                                                    alignItems: 'center'
                                                                },
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((PhoneInTalkOutlined_default()), {
                                                                    color: 'secondary',
                                                                    sx: {
                                                                        mx: 1,
                                                                        fontSize: 50
                                                                    }
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                                sx: {
                                                                    display: 'flex',
                                                                    flexDirection: 'column',
                                                                    textAlign: 'center',
                                                                    mt: 1
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                                        component: "span",
                                                                        sx: {
                                                                            fontSize: 14,
                                                                            color: constants/* SECONDARY_COLOR */.Vz,
                                                                            fontWeight: 'bold'
                                                                        },
                                                                        children: "Have any Question?"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                                        component: "span",
                                                                        sx: {
                                                                            color: '#fff',
                                                                            fontSize: 20
                                                                        },
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                            href: "tel: +8801687266144",
                                                                            children: "+8801687266144"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ScrollTop, {
                elRef: backToTopAnchor,
                children: /*#__PURE__*/ jsx_runtime_.jsx((Fab_default()), {
                    color: "secondary",
                    size: "small",
                    "aria-label": "scroll back to top",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowUp_default()), {
                        sx: {
                            color: '#000'
                        }
                    })
                })
            })
        ]
    }));
};


/***/ })

};
;