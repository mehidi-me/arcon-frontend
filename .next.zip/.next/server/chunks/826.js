"use strict";
exports.id = 826;
exports.ids = [826];
exports.modules = {

/***/ 4826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AdminLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(1175);
// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(9755);
// EXTERNAL MODULE: ./recoil/atoms/userAtom.ts
var userAtom = __webpack_require__(8793);
// EXTERNAL MODULE: external "@mui/material/AppBar"
var AppBar_ = __webpack_require__(3882);
var AppBar_default = /*#__PURE__*/__webpack_require__.n(AppBar_);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/Toolbar"
var Toolbar_ = __webpack_require__(1431);
var Toolbar_default = /*#__PURE__*/__webpack_require__.n(Toolbar_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "@mui/material/IconButton"
var IconButton_ = __webpack_require__(7934);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_);
// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var Menu_ = __webpack_require__(3365);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/icons-material/AccountCircle"
var AccountCircle_ = __webpack_require__(1883);
var AccountCircle_default = /*#__PURE__*/__webpack_require__.n(AccountCircle_);
// EXTERNAL MODULE: external "@mui/material/MenuItem"
var MenuItem_ = __webpack_require__(9271);
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem_);
// EXTERNAL MODULE: external "@mui/material/Menu"
var material_Menu_ = __webpack_require__(8125);
var material_Menu_default = /*#__PURE__*/__webpack_require__.n(material_Menu_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/icons-material/AccountTree"
var AccountTree_ = __webpack_require__(6464);
var AccountTree_default = /*#__PURE__*/__webpack_require__.n(AccountTree_);
// EXTERNAL MODULE: external "@mui/icons-material/ExpandLess"
var ExpandLess_ = __webpack_require__(6174);
var ExpandLess_default = /*#__PURE__*/__webpack_require__.n(ExpandLess_);
// EXTERNAL MODULE: external "@mui/icons-material/ExpandMore"
var ExpandMore_ = __webpack_require__(8148);
var ExpandMore_default = /*#__PURE__*/__webpack_require__.n(ExpandMore_);
// EXTERNAL MODULE: external "@mui/icons-material/ListAlt"
var ListAlt_ = __webpack_require__(4846);
var ListAlt_default = /*#__PURE__*/__webpack_require__.n(ListAlt_);
// EXTERNAL MODULE: external "@mui/icons-material/Add"
var Add_ = __webpack_require__(6146);
var Add_default = /*#__PURE__*/__webpack_require__.n(Add_);
// EXTERNAL MODULE: external "@mui/icons-material/PermMedia"
var PermMedia_ = __webpack_require__(3637);
var PermMedia_default = /*#__PURE__*/__webpack_require__.n(PermMedia_);
;// CONCATENATED MODULE: ./components/admin/drawer.tsx










function AdminDrawer({ drawerOpen , toggleDrawer  }) {
    const router = (0,router_.useRouter)();
    const { 0: collapseOpen , 1: setCollapseOpen  } = (0,external_react_.useState)(true);
    const handleListCollapse = ()=>{
        setCollapseOpen(!collapseOpen);
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Drawer, {
        anchor: "left",
        open: drawerOpen,
        onClose: toggleDrawer(false),
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
            sx: {
                minWidth: 250
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.List, {
                component: "nav",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.ListItemButton, {
                        onClick: handleListCollapse,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemIcon, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((AccountTree_default()), {
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                primary: "Projects"
                            }),
                            collapseOpen ? /*#__PURE__*/ jsx_runtime_.jsx((ExpandLess_default()), {
                            }) : /*#__PURE__*/ jsx_runtime_.jsx((ExpandMore_default()), {
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Collapse, {
                        in: collapseOpen,
                        timeout: "auto",
                        unmountOnExit: true,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                            sx: {
                                pl: 4
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.ListItemButton, {
                                    onClick: ()=>router.push("/admin")
                                    ,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemIcon, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((ListAlt_default()), {
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                            primary: "All Projects"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.ListItemButton, {
                                    onClick: ()=>router.push("/admin/create")
                                    ,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemIcon, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Add_default()), {
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                            primary: "Add New"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.ListItemButton, {
                        onClick: ()=>router.push("/admin/media")
                        ,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemIcon, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((PermMedia_default()), {
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                primary: "Media"
                            })
                        ]
                    })
                ]
            })
        })
    }));
}

;// CONCATENATED MODULE: ./components/admin/navbar.tsx

















function AdminNavbar({ appBarTitle  }) {
    const [userState, setUserState] = (0,external_recoil_.useRecoilState)(userAtom/* userAtom */.L);
    const router = (0,router_.useRouter)();
    const [auth, setAuth] = external_react_.useState(true);
    const [anchorEl, setAnchorEl] = external_react_.useState(null);
    const [drawerOpen, setDrawerOpen] = external_react_.useState(false);
    const toggleDrawer = (open)=>(event)=>{
            if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
                return;
            }
            setDrawerOpen(open);
        }
    ;
    const handleChange = (event)=>{
        setAuth(event.target.checked);
    };
    const handleMenu = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    const logoutMutation = (0,external_react_query_.useMutation)(async ()=>{
        return external_axios_default().post('/auth/logout');
    }, {
        onSuccess: ()=>{
            setUserState(null);
            return router.push('/admin/login');
        }
    });
    const handleLogout = ()=>{
        return logoutMutation.mutate();
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
        sx: {
            flexGrow: 1
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((AppBar_default()), {
                position: "static",
                color: "secondary",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Toolbar_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            size: "large",
                            edge: "start",
                            "aria-label": "menu",
                            sx: {
                                mr: 2,
                                color: 'white'
                            },
                            onClick: toggleDrawer(true),
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Menu_default()), {
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h6",
                            component: "div",
                            sx: {
                                flexGrow: 1,
                                color: 'white'
                            },
                            children: appBarTitle
                        }),
                        auth && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    size: "large",
                                    "aria-label": "account of current user",
                                    "aria-controls": "menu-appbar",
                                    "aria-haspopup": "true",
                                    onClick: handleMenu,
                                    sx: {
                                        color: 'white'
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((AccountCircle_default()), {
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((material_Menu_default()), {
                                    id: "menu-appbar",
                                    anchorEl: anchorEl,
                                    anchorOrigin: {
                                        vertical: 'top',
                                        horizontal: 'right'
                                    },
                                    keepMounted: true,
                                    transformOrigin: {
                                        vertical: 'top',
                                        horizontal: 'right'
                                    },
                                    open: Boolean(anchorEl),
                                    onClose: handleClose,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                                        onClick: handleLogout,
                                        children: "Logout"
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AdminDrawer, {
                drawerOpen: drawerOpen,
                toggleDrawer: toggleDrawer
            })
        ]
    }));
};

;// CONCATENATED MODULE: ./components/admin/adminLayout.tsx









function AdminLayout({ children , pageTitle  }) {
    const [user, setUser] = (0,external_recoil_.useRecoilState)(userAtom/* userAtom */.L);
    const router = (0,router_.useRouter)();
    const {} = (0,external_react_query_.useQuery)('userProfile', async ()=>{
        const { data  } = await external_axios_default().get('/auth/profile');
        return data;
    }, {
        onSuccess: (data)=>{
            setUser(data);
        },
        onError: ()=>{
            return router.push('/admin/login');
        }
    });
    if (!user) {
        return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "100vh",
            children: /*#__PURE__*/ jsx_runtime_.jsx(material_.CircularProgress, {
                color: 'secondary'
            })
        }));
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(AdminNavbar, {
                appBarTitle: pageTitle
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            })
        ]
    }));
};


/***/ }),

/***/ 8793:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ userAtom)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const userAtom = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "user",
    default: null
});


/***/ })

};
;