"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "@emotion/react"
const react_namespaceObject = require("@emotion/react");
// EXTERNAL MODULE: external "@mui/material/CssBaseline"
var CssBaseline_ = __webpack_require__(4960);
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: external "nextjs-progressbar"
const external_nextjs_progressbar_namespaceObject = require("nextjs-progressbar");
var external_nextjs_progressbar_default = /*#__PURE__*/__webpack_require__.n(external_nextjs_progressbar_namespaceObject);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(1175);
// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(9755);
// EXTERNAL MODULE: ./utils/constants.ts
var constants = __webpack_require__(9830);
// EXTERNAL MODULE: ./utils/createEmotionCache.ts + 1 modules
var createEmotionCache = __webpack_require__(5742);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./utils/theme.ts


const theme = (0,material_.createTheme)({
    palette: {
        secondary: {
            main: constants/* SECONDARY_COLOR */.Vz
        }
    },
    typography: {
        fontFamily: [
            'Cerebri-Sans',
            'Arial',
            'sans-serif'
        ].join(',')
    }
});

;// CONCATENATED MODULE: ./pages/_app.tsx













(external_axios_default()).defaults.baseURL = "https://api.arconinterior.com.bd";
(external_axios_default()).defaults.withCredentials = true;
// Client-side cache, shared for the whole session of the user in the browser.
const clientSideEmotionCache = (0,createEmotionCache/* default */.Z)();
function MyApp(props) {
    const queryClient = new external_react_query_.QueryClient({
        defaultOptions: {
            queries: {
                staleTime: 1000 * 60
            }
        }
    });
    const { Component , emotionCache =clientSideEmotionCache , pageProps  } = props;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_namespaceObject.CacheProvider, {
        value: emotionCache,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "viewport",
                    content: "initial-scale=1, width=device-width"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(styles_.ThemeProvider, {
                theme: theme,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CssBaseline_default()), {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_query_.QueryClientProvider, {
                        client: queryClient,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_recoil_.RecoilRoot, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((external_nextjs_progressbar_default()), {
                                    color: constants/* SECONDARY_COLOR */.Vz,
                                    startPosition: 0.3,
                                    stopDelayMs: 200,
                                    height: 3,
                                    showOnShallow: true,
                                    options: {
                                        showSpinner: false
                                    }
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                                    ...pageProps
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 9830:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Vz": () => (/* binding */ SECONDARY_COLOR),
/* harmony export */   "cE": () => (/* binding */ DANGER_COLOR),
/* harmony export */   "lx": () => (/* binding */ DANGER_COLOR_DARK),
/* harmony export */   "AX": () => (/* binding */ TERTIARY_COLOR)
/* harmony export */ });
/* unused harmony export API_URL */
const SECONDARY_COLOR = '#FAE80C';
const DANGER_COLOR = '#FF0000';
const DANGER_COLOR_DARK = '#ff2400';
const API_URL = (/* unused pure expression or super */ null && ("https://api.arconinterior.com.bd"));
const TERTIARY_COLOR = '#F3C430';


/***/ }),

/***/ 5742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ createEmotionCache)
});

;// CONCATENATED MODULE: external "@emotion/cache"
const cache_namespaceObject = require("@emotion/cache");
var cache_default = /*#__PURE__*/__webpack_require__.n(cache_namespaceObject);
;// CONCATENATED MODULE: ./utils/createEmotionCache.ts

function createEmotionCache() {
    return cache_default()({
        key: "css"
    });
};


/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 4960:
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8789));
module.exports = __webpack_exports__;

})();