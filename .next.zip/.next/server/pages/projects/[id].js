"use strict";
(() => {
var exports = {};
exports.id = 92;
exports.ids = [92];
exports.modules = {

/***/ 5569:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SingleProject),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./backend/projects/index.ts
var projects = __webpack_require__(6245);
// EXTERNAL MODULE: ./components/common/footer/index.tsx + 2 modules
var footer = __webpack_require__(6371);
// EXTERNAL MODULE: ./components/common/header/index.tsx + 1 modules
var header = __webpack_require__(2029);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/projects/businessIdea/index.tsx




function BusinessIdea({ project  }) {
    const { ideas , images , _id , title , featureImg  } = project;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                variant: "h4",
                children: "Best Business Ideas"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                dangerouslySetInnerHTML: {
                    __html: ideas
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                container: true,
                spacing: 2,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                children: images.map((img)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 4,
                        sm: 6,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            src: img.url,
                            alt: title,
                            height: 600,
                            width: 600,
                            objectFit: "cover",
                            placeholder: "blur",
                            blurDataURL: "https://i.ibb.co/KV27zx8/skeleton.jpg"
                        })
                    }, img._id)
                )
            })
        ]
    }));
};

// EXTERNAL MODULE: ./components/common/Title/index.tsx
var Title = __webpack_require__(4353);
;// CONCATENATED MODULE: ./components/projects/challenge/index.tsx




function Challenge({ challenge  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
            sx: {
                my: 3
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    fontWeight: "500",
                    variant: "h4",
                    children: "Project Challenges"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Title/* Description */.dk, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: challenge
                        }
                    })
                })
            ]
        })
    }));
};

// EXTERNAL MODULE: ./components/common/SocialIcon/index.tsx + 1 modules
var SocialIcon = __webpack_require__(2205);
// EXTERNAL MODULE: ./utils/constants.ts
var constants = __webpack_require__(9830);
;// CONCATENATED MODULE: ./components/projects/projectDetails/index.tsx






function ProjectDetails({ project  }) {
    const { featureImg , name , title , location , workingYear  } = project;
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        sx: {
            my: 5
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
            sx: {
                position: 'relative'
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                        src: featureImg.url,
                        alt: title,
                        objectFit: "cover",
                        width: 1200,
                        height: 700,
                        loading: "lazy"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        mt: {
                            xs: 3
                        }
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        position: {
                            md: 'absolute',
                            xs: 'static'
                        },
                        sx: {
                            backgroundColor: 'black',
                            bottom: -30,
                            right: 40,
                            zIndex: 2,
                            color: 'white',
                            p: 3
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                        variant: "h6",
                                        sx: {
                                            my: 1,
                                            color: constants/* SECONDARY_COLOR */.Vz
                                        },
                                        children: [
                                            "Project Details:",
                                            ' '
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                        container: true,
                                        spacing: 3,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                                item: true,
                                                md: 6,
                                                xs: 6,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        children: "Project"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        variant: "caption",
                                                        children: title
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                                item: true,
                                                md: 6,
                                                xs: 6,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        children: "Clients"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        variant: "caption",
                                                        children: name
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                                item: true,
                                                md: 6,
                                                xs: 6,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        children: "Location"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        variant: "caption",
                                                        children: location
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                                item: true,
                                                md: 6,
                                                xs: 6,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        children: "Project Year"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        variant: "caption",
                                                        children: workingYear
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                mt: "10px",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        fontWeight: "700",
                                        children: "Share Media: "
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                target: "_blank",
                                                href: "https://www.facebook.com/arcon.interior/",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* Facebook */.s1, {
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                target: "_blank",
                                                href: "https://www.instagram.com/arcon_interiors/",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* Instagram */.mr, {
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                target: "_blank",
                                                href: "https://www.linkedin.com/home/",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* LinkedIn */.yh, {
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                target: "_blank",
                                                href: "https://www.pinterest.com/",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* Pinterest */.nz, {
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    }));
};

// EXTERNAL MODULE: external "@mui/icons-material/ArrowBackIos"
var ArrowBackIos_ = __webpack_require__(4195);
var ArrowBackIos_default = /*#__PURE__*/__webpack_require__.n(ArrowBackIos_);
// EXTERNAL MODULE: external "@mui/icons-material/ArrowForwardIos"
var ArrowForwardIos_ = __webpack_require__(1658);
var ArrowForwardIos_default = /*#__PURE__*/__webpack_require__.n(ArrowForwardIos_);
// EXTERNAL MODULE: ./components/common/Button/index.tsx
var Button = __webpack_require__(8133);
// EXTERNAL MODULE: ./components/common/project/styles.ts
var styles = __webpack_require__(3097);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: ./components/common/project/styles.module.css
var styles_module = __webpack_require__(3887);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
;// CONCATENATED MODULE: ./components/projects/relatedProject/index.tsx














function RelatedProject({ relatedProjects  }) {
    const arrowStyle = {
        color: constants/* SECONDARY_COLOR */.Vz,
        opacity: 0.6,
        '&:hover': {
            color: constants/* SECONDARY_COLOR */.Vz
        }
    };
    const settings = {
        infinite: false,
        speed: 500,
        slidesToShow: 3.2,
        slidesToScroll: 1,
        initialSlide: 0,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true
                }
            },
            {
                breakpoint: 990,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 620,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    prevArrow: /*#__PURE__*/ jsx_runtime_.jsx((ArrowBackIos_default()), {
                        sx: {
                            ...arrowStyle
                        }
                    }),
                    nextArrow: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {
                        sx: {
                            ...arrowStyle
                        }
                    })
                }
            }, 
        ]
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    variant: "h4",
                    children: "Related Projects"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    ml: {
                        md: 10,
                        xl: 40
                    },
                    overflow: 'hidden',
                    px: {
                        xs: 4,
                        sm: 0
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                    ...settings,
                    children: relatedProjects.map((project)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(styles/* ProjectContainer */.XR, {
                                className: (styles_module_default()).projectContainer,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                        className: (styles_module_default()).projectImage,
                                        src: project.featureImg.url,
                                        alt: project.title,
                                        width: 500,
                                        height: 600,
                                        objectFit: "cover",
                                        placeholder: "blur",
                                        blurDataURL: "https://i.ibb.co/KV27zx8/skeleton.jpg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        className: (styles_module_default()).hoverOverlay,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(styles/* ProjectDetails */.ur, {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                className: (styles_module_default()).detailsContainer,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                        href: `/projects/${project._id}`,
                                                        passHref: true,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(styles/* ProjectName */.vV, {
                                                            variant: "h5",
                                                            children: project.title
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(styles/* ProjectDescription */.Wn, {
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                                            sx: {
                                                                lineHeight: {
                                                                    xs: 1.7,
                                                                    xl: 2
                                                                },
                                                                fontSize: 'inherit'
                                                            },
                                                            component: "p",
                                                            children: [
                                                                project.description.substring(0, 150),
                                                                project.description.length < 150 ? ' ' : '...'
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                        sx: {
                                                            position: 'absolute',
                                                            bottom: '10px'
                                                        },
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                            href: `/projects/${project._id}`,
                                                            passHref: true,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* ProjectBtn */.Iz, {
                                                                children: "read more +"
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        }, project._id)
                    )
                })
            })
        ]
    }));
};

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./pages/projects/[id].tsx











function SingleProject({ project  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                        children: [
                            project.title,
                            " - Arcon"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                component: "header",
                children: /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.Z, {
                    pageTitle: "Arcon Work",
                    breadcrumbTitle: "Arcon Work"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                component: "main",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ProjectDetails, {
                        project: project
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(BusinessIdea, {
                        project: project
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Challenge, {
                        challenge: project.challenges
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(RelatedProject, {
                        relatedProjects: project === null || project === void 0 ? void 0 : project.relatedProjects
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                component: "footer",
                children: /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {
                })
            })
        ]
    }));
};
const getServerSideProps = async ({ params  })=>{
    const { id  } = params;
    const project = await (0,projects/* getSingleProject */.TR)(id);
    return {
        props: {
            project
        }
    };
};


/***/ }),

/***/ 7915:
/***/ ((module) => {

module.exports = require("@mui/icons-material");

/***/ }),

/***/ 7541:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccessTimeFilled");

/***/ }),

/***/ 4195:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowBackIos");

/***/ }),

/***/ 1658:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForwardIos");

/***/ }),

/***/ 2081:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Call");

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 9226:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Email");

/***/ }),

/***/ 7666:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 3467:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 3281:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 9881:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 5939:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LinkedIn");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PhoneInTalkOutlined");

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Pinterest");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 7185:
/***/ ((module) => {

module.exports = require("@mui/material/Breadcrumbs");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4960:
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 3661:
/***/ ((module) => {

module.exports = require("@mui/material/Fab");

/***/ }),

/***/ 5768:
/***/ ((module) => {

module.exports = require("@mui/material/Popover");

/***/ }),

/***/ 1528:
/***/ ((module) => {

module.exports = require("@mui/material/Zoom");

/***/ }),

/***/ 5574:
/***/ ((module) => {

module.exports = require("@mui/material/colors");

/***/ }),

/***/ 4156:
/***/ ((module) => {

module.exports = require("@mui/material/useScrollTrigger");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,664,133,780,29,847], () => (__webpack_exec__(5569)));
module.exports = __webpack_exports__;

})();