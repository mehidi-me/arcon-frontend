(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 9841:
/***/ ((module) => {

// Exports
module.exports = {
	"parent": "styles_parent__QqBsP",
	"image1": "styles_image1__wN3Wn",
	"image2": "styles_image2__SPgPc",
	"tabScreen": "styles_tabScreen__iJ0bx"
};


/***/ }),

/***/ 6817:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "styles_container__ElOo_",
	"contactInfo": "styles_contactInfo__PJ08d",
	"formContainer": "styles_formContainer__xHlpu"
};


/***/ }),

/***/ 4803:
/***/ ((module) => {

// Exports
module.exports = {
	"headerImage": "styles_headerImage__EG6nd",
	"slideInLeft": "styles_slideInLeft__GLk79",
	"headerText": "styles_headerText__d8AG_",
	"animateLeftToRight": "styles_animateLeftToRight__XU0zO",
	"animateRightToLeft": "styles_animateRightToLeft__9jP1P",
	"slideInRight": "styles_slideInRight___E7pU",
	"animateButton": "styles_animateButton__m2kF_",
	"slideUp": "styles_slideUp__8Nloy",
	"borderFadeIn": "styles_borderFadeIn__RSZ8L",
	"fadeIn": "styles_fadeIn__gNhog"
};


/***/ }),

/***/ 7202:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "styles_container__dVsOb",
	"reviewCard": "styles_reviewCard__dY4Fp",
	"avatarContainer": "styles_avatarContainer__afr_k",
	"avatar": "styles_avatar__lD2Tp",
	"img": "styles_img__z_bcF",
	"content": "styles_content__BSoPQ"
};


/***/ }),

/***/ 9396:
/***/ ((module) => {

// Exports
module.exports = {
	"aboutArcon": "styles_aboutArcon__5q1Ss"
};


/***/ }),

/***/ 3098:
/***/ ((module) => {

// Exports
module.exports = {
	"image": "styles_image__X2zYV",
	"singleWork": "styles_singleWork__rhG6y",
	"serial": "styles_serial__cGALm"
};


/***/ }),

/***/ 3737:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./backend/projects/index.ts
var backend_projects = __webpack_require__(6245);
// EXTERNAL MODULE: ./components/common/navbar/index.tsx + 2 modules
var navbar = __webpack_require__(35);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/common/footer/index.tsx + 2 modules
var footer = __webpack_require__(6371);
;// CONCATENATED MODULE: external "@mui/icons-material/Bed"
const Bed_namespaceObject = require("@mui/icons-material/Bed");
var Bed_default = /*#__PURE__*/__webpack_require__.n(Bed_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Escalator"
const Escalator_namespaceObject = require("@mui/icons-material/Escalator");
var Escalator_default = /*#__PURE__*/__webpack_require__.n(Escalator_namespaceObject);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
;// CONCATENATED MODULE: external "@mui/material/LinearProgress"
const LinearProgress_namespaceObject = require("@mui/material/LinearProgress");
var LinearProgress_default = /*#__PURE__*/__webpack_require__.n(LinearProgress_namespaceObject);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./utils/constants.ts
var constants = __webpack_require__(9830);
// EXTERNAL MODULE: ./components/common/Title/index.tsx
var Title = __webpack_require__(4353);
// EXTERNAL MODULE: ./components/home/aboutArcon/styles.module.css
var styles_module = __webpack_require__(9841);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
;// CONCATENATED MODULE: ./components/home/aboutArcon/index.tsx











function AboutArcon() {
    const iconP = {
        fontSize: '4rem',
        color: constants/* TERTIARY_COLOR */.AX
    };
    const pBar = {
        py: 3,
        position: 'relative'
    };
    // percentage bar diagram
    const BorderLinearProgress = (0,styles_.styled)((LinearProgress_default()))(({ theme  })=>({
            height: 6,
            borderRadius: 5,
            [`&.${LinearProgress_namespaceObject.linearProgressClasses.colorPrimary}`]: {
                backgroundColor: theme.palette.grey[800]
            },
            [`& .${LinearProgress_namespaceObject.linearProgressClasses.bar}`]: {
                borderRadius: 5,
                backgroundColor: constants/* TERTIARY_COLOR */.AX
            }
        })
    );
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
        sx: {
            my: 8
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
            container: true,
            spacing: 3,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    lg: 6,
                    md: 12,
                    sm: 12,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                        className: (styles_module_default()).tabScreen,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            src: "/images/arcon10.jpg",
                            alt: "Arcon Work Image",
                            width: 600,
                            height: 600,
                            objectFit: "cover",
                            loading: "lazy"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                    item: true,
                    lg: 6,
                    md: 12,
                    sm: 12,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* SectionTitle */.NZ, {
                            children: "About Arcon"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            variant: "h4",
                            sx: {
                                fontSize: {
                                    xs: 30,
                                    sm: 40
                                }
                            },
                            component: "div",
                            fontWeight: "700",
                            gutterBottom: true,
                            children: "We Create The Art Of Stylish Living Stylishly"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* Description */.dk, {
                            sx: {
                                my: 3
                            },
                            children: "Arcon design consultancy firm that brings sensitivity to the design top restaurants, hotels, offices & homes around the world. We stand for quality, safety and credibility, so you could be sure about our work"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            container: true,
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                    item: true,
                                    display: "flex",
                                    md: 6,
                                    xs: 12,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Escalator_default()), {
                                                sx: iconP
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    variant: "h6",
                                                    children: "Residential Interior"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Title/* Description */.dk, {
                                                    variant: "body2",
                                                    children: "We do all types of the interior designing, decoration work"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                    item: true,
                                    md: 6,
                                    display: "flex",
                                    xs: 12,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Bed_default()), {
                                                sx: iconP
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    variant: "h6",
                                                    noWrap: true,
                                                    children: "Modern Living Interior"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Title/* Description */.dk, {
                                                    variant: "body2",
                                                    children: "We are master of renovation & innovation any kind of rooms."
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                            sx: {
                                my: 1
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                                    sx: pBar,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* BarTitle */.k3, {
                                            children: "Riding Trainer"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(BorderLinearProgress, {
                                            variant: "determinate",
                                            value: 73
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* Percentage */.$t, {
                                            children: "73%"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                                    sx: pBar,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* BarTitle */.k3, {
                                            children: "Exterior Designer"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(BorderLinearProgress, {
                                            variant: "determinate",
                                            value: 64
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* Percentage */.$t, {
                                            children: "64%"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                                    sx: pBar,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* BarTitle */.k3, {
                                            children: "Happy Clients"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(BorderLinearProgress, {
                                            variant: "determinate",
                                            value: 93
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* Percentage */.$t, {
                                            children: "93%"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};

;// CONCATENATED MODULE: external "@mui/icons-material/ArrowForward"
const ArrowForward_namespaceObject = require("@mui/icons-material/ArrowForward");
var ArrowForward_default = /*#__PURE__*/__webpack_require__.n(ArrowForward_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Checkbox"
const Checkbox_namespaceObject = require("@mui/material/Checkbox");
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/FormControlLabel"
const FormControlLabel_namespaceObject = require("@mui/material/FormControlLabel");
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/FormGroup"
const FormGroup_namespaceObject = require("@mui/material/FormGroup");
var FormGroup_default = /*#__PURE__*/__webpack_require__.n(FormGroup_namespaceObject);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(5609);
// EXTERNAL MODULE: ./components/common/Button/index.tsx
var Button = __webpack_require__(8133);
// EXTERNAL MODULE: ./components/common/Dialog/index.tsx + 1 modules
var Dialog = __webpack_require__(3036);
;// CONCATENATED MODULE: ./components/home/contact/form.tsx











const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
const validationSchema = external_yup_.object({
    email: external_yup_.string().email('Enter a valid email').required('Email is required'),
    name: external_yup_.string().required('Name is required'),
    phone: external_yup_.string().required('Phone number is required').matches(phoneRegExp, 'Phone number is not valid').min(11, 'too short').max(11, 'too long'),
    subject: external_yup_.string().required('subject is required'),
    address: external_yup_.string().required('address is required'),
    zip: external_yup_.string().required('Zip Code is required'),
    message: external_yup_.string().required('Message is required'),
    checkbox: external_yup_.string().required('Check is required')
});
function Form() {
    // Controlling dialog
    const { 0: isDialogOpen , 1: setIsDialogOpen  } = (0,external_react_.useState)(false);
    const handleDialogClose = ()=>{
        setIsDialogOpen(false);
        resetForm();
    };
    const { handleChange , handleSubmit , values , touched , errors , resetForm  } = (0,external_formik_.useFormik)({
        initialValues: {
            name: '',
            email: '',
            phone: '',
            subject: '',
            address: '',
            zip: '',
            message: '',
            checkbox: false
        },
        validationSchema: validationSchema,
        onSubmit: (_values)=>{
            setIsDialogOpen(true);
        }
    });
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
        sx: {
            my: 5
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("form", {
            onSubmit: handleSubmit,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                container: true,
                sx: {
                    '& .MuiOutlinedInput-root': {
                        color: '#fff',
                        '& fieldset': {
                            borderColor: '#292929'
                        },
                        '&:hover fieldset': {
                            borderColor: '#292929'
                        },
                        '&.Mui-focused fieldset': {
                            borderColor: '#fa8e1b'
                        }
                    }
                },
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            sx: {
                                fontWeight: 700,
                                color: '#ffffff',
                                fontSize: {
                                    xs: 26,
                                    sm: 40
                                }
                            },
                            variant: "h4",
                            children: "Send Your Message To Us"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                            fullWidth: true,
                            id: "name",
                            name: "name",
                            type: "text",
                            placeholder: "Your Name*",
                            value: values.name,
                            onChange: handleChange,
                            error: touched.name && Boolean(errors.name),
                            helperText: touched.name && errors.name
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                            fullWidth: true,
                            id: "email",
                            type: "email",
                            name: "email",
                            placeholder: "Your Email*",
                            value: values.email,
                            onChange: handleChange,
                            error: touched.email && Boolean(errors.email),
                            helperText: touched.email && errors.email
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                            fullWidth: true,
                            id: "phone",
                            name: "phone",
                            placeholder: "Your Phone*",
                            value: values.phone,
                            onChange: handleChange,
                            error: touched.phone && Boolean(errors.phone),
                            helperText: touched.phone && errors.phone
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                            fullWidth: true,
                            id: "subject",
                            name: "subject",
                            type: "text",
                            placeholder: "Your Subject*",
                            value: values.subject,
                            onChange: handleChange,
                            error: touched.subject && Boolean(errors.subject),
                            helperText: touched.subject && errors.subject
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                            fullWidth: true,
                            id: "address",
                            name: "address",
                            type: "text",
                            placeholder: "Address*",
                            value: values.address,
                            onChange: handleChange,
                            error: touched.address && Boolean(errors.address),
                            helperText: touched.address && errors.address
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                            fullWidth: true,
                            id: "zip",
                            name: "zip",
                            placeholder: "Zip Code*",
                            value: values.zip,
                            onChange: handleChange,
                            error: touched.zip && Boolean(errors.zip),
                            helperText: touched.zip && errors.zip
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 12,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                            id: "message",
                            name: "message",
                            type: "text",
                            placeholder: "Message*",
                            "aria-label": "empty textarea",
                            minRows: 6,
                            multiline: true,
                            fullWidth: true,
                            value: values.message,
                            onChange: handleChange,
                            error: touched.message && Boolean(errors.message),
                            helperText: touched.message && errors.message
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 12,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                sx: {
                                    '& .MuiTypography-root': {
                                        color: '#a3a09d',
                                        fontSize: {
                                            xs: 12,
                                            sm: 18
                                        }
                                    },
                                    '& .MuiSvgIcon-root': {
                                        fill: '#a3a09d'
                                    }
                                },
                                control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                    size: "small",
                                    color: "secondary"
                                }),
                                label: "It would be great to hear from you! If you got any questions."
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        md: 12,
                        xs: 12,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* OrangeBtn */.iI, {
                                fullWidth: true,
                                type: "submit",
                                children: [
                                    "Send Message \xa0",
                                    /*#__PURE__*/ jsx_runtime_.jsx((ArrowForward_default()), {
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Dialog/* default */.Z, {
                                open: isDialogOpen,
                                onClose: handleDialogClose,
                                modalTitle: "Thanks for contacting us",
                                modalDesc: "Thank you for contacting Arcon Inoterior. We received your message. We will reply your message within 24 hours.",
                                closeButtonTitle: "Ok, I understand"
                            })
                        ]
                    })
                ]
            })
        })
    }));
};

// EXTERNAL MODULE: ./components/home/contact/styles.module.css
var contact_styles_module = __webpack_require__(6817);
var contact_styles_module_default = /*#__PURE__*/__webpack_require__.n(contact_styles_module);
// EXTERNAL MODULE: external "@mui/icons-material/Call"
var Call_ = __webpack_require__(2081);
var Call_default = /*#__PURE__*/__webpack_require__.n(Call_);
// EXTERNAL MODULE: ./components/common/SocialIcon/index.tsx + 1 modules
var SocialIcon = __webpack_require__(2205);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/home/contact/index.tsx









function Contact() {
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
        maxWidth: "xl",
        sx: {
            my: 5,
            p: {
                xs: 0,
                sm: 0
            }
        },
        id: "contact",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
            container: true,
            spacing: 2,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    md: 6,
                    className: (contact_styles_module_default()).container,
                    sx: {
                        top: {
                            md: '40px'
                        }
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        className: (contact_styles_module_default()).contactInfo,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                            spacing: 2,
                            sx: {
                                backgroundColor: 'white',
                                m: '10%',
                                p: {
                                    xs: 5,
                                    md: 6,
                                    sm: 4
                                },
                                textAlign: 'center'
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Title/* Title */.Dx, {
                                    variant: "h4",
                                    children: "Emergancy Interiors Services"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Title/* Description */.dk, {
                                    children: "Please do not hesitate to send us a message. We are looking forward to hearing from you."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Call_default()), {
                                                sx: {
                                                    color: constants/* SECONDARY_COLOR */.Vz,
                                                    fontSize: '2.5rem',
                                                    mt: '5px'
                                                }
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                            sx: {
                                                ml: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    fontSize: "16px",
                                                    fontWeight: "700",
                                                    children: "Waiting Call Us"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    fontSize: "16px",
                                                    fontWeight: "700",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "tel: +8801687266144",
                                                        children: "+8801687266144"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                    sx: {
                                        display: 'flex',
                                        justifyContent: 'center'
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "https://www.facebook.com/arcon.interior/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* Facebook */.s1, {
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "https://www.instagram.com/arcon_interiors/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* Instagram */.mr, {
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "https://www.linkedin.com/home/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* LinkedIn */.yh, {
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "https://www.pinterest.com/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(SocialIcon/* Pinterest */.nz, {
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    md: 6,
                    className: (contact_styles_module_default()).formContainer,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Form, {
                    })
                })
            ]
        })
    }));
};

;// CONCATENATED MODULE: external "@mui/icons-material/LocationOn"
const LocationOn_namespaceObject = require("@mui/icons-material/LocationOn");
var LocationOn_default = /*#__PURE__*/__webpack_require__.n(LocationOn_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Phone"
const Phone_namespaceObject = require("@mui/icons-material/Phone");
var Phone_default = /*#__PURE__*/__webpack_require__.n(Phone_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/MailOutline"
const MailOutline_namespaceObject = require("@mui/icons-material/MailOutline");
var MailOutline_default = /*#__PURE__*/__webpack_require__.n(MailOutline_namespaceObject);
;// CONCATENATED MODULE: ./components/common/ContactInfo/style.ts
const contactInfoWrapper = {
    backgroundColor: " #000",
    width: "80px",
    height: "100%",
    opacity: ".6",
    position: "absolute",
    top: "0",
    left: "0",
    color: "#fff",
    display: {
        lg: "block",
        xs: "none"
    },
    fontSize: "13px",
    pt: "88px"
};
const verticalContent = {
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-evenly",
    alignItems: "center",
    height: "100%",
    width: "100%"
};
const makeContentChildVertical = {
    display: "flex",
    alignItems: "center",
    writingMode: "vertical-lr",
    transform: "rotate(-180deg)"
};
const setIconVertically = {
    writingMode: "vertical-lr",
    transform: "rotate(-270deg)",
    mb: 1,
    fontSize: "14px"
};

;// CONCATENATED MODULE: ./components/common/ContactInfo/index.tsx







function ContactInfo() {
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        sx: contactInfoWrapper,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
            sx: verticalContent,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                    sx: makeContentChildVertical,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((MailOutline_default()), {
                            color: "secondary",
                            sx: setIconVertically
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            component: "div",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "mailto:arconconsultancybd@gmail.com",
                                children: "arconconsultancybd@gmail.com"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                    sx: makeContentChildVertical,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Phone_default()), {
                            color: "secondary",
                            sx: setIconVertically
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            component: "div",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "tel:+8801687266144",
                                children: "+8801687266144"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                    sx: makeContentChildVertical,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((LocationOn_default()), {
                            color: "secondary",
                            sx: setIconVertically
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            component: "div",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: "Zakir Hossain Road, Khulshi"
                            })
                        })
                    ]
                })
            ]
        })
    }));
};

;// CONCATENATED MODULE: ./components/home/header/style.ts

const horizontalBorder = {
    backgroundColor: constants/* SECONDARY_COLOR */.Vz,
    height: '130%',
    width: '5px',
    position: 'absolute',
    top: '-15%',
    display: {
        xs: 'none',
        md: 'block'
    }
};
const headerTextLeftBorder = {
    ...horizontalBorder,
    left: '-5%'
};
const headerTextRightBorder = {
    ...horizontalBorder,
    right: '-5%'
};
const topBorder = {
    backgroundColor: constants/* SECONDARY_COLOR */.Vz,
    height: '5px',
    width: '200px',
    position: 'absolute',
    top: '-15%',
    display: {
        xs: 'none',
        md: 'block'
    }
};
const headerRightAdditionalInfo = {
    display: {
        xs: 'none',
        sm: 'flex'
    },
    flexDirection: 'row',
    justifyContent: 'space-between',
    p: 1,
    m: 1,
    fontSize: {
        xs: 12,
        md: 20
    },
    color: '#fff',
    width: {
        md: '90%',
        lg: '60%',
        sm: '60%'
    },
    margin: {
        sm: '0 auto 0 auto',
        md: '0 0 0 auto'
    }
};
const headerTextLeftTopBorder = {
    ...topBorder,
    left: '-5%'
};
const headerTextRightTopBorder = {
    ...topBorder,
    right: '-5%'
};
const bottomBorder = {
    backgroundColor: constants/* SECONDARY_COLOR */.Vz,
    height: '5px',
    width: '200px',
    position: 'absolute',
    bottom: '-15%',
    display: {
        xs: 'none',
        md: 'block'
    }
};
const headerTextLeftBottomBorder = {
    ...bottomBorder,
    left: '-5%'
};
const headerTextRightBottomBorder = {
    ...bottomBorder,
    right: '-5%'
};

// EXTERNAL MODULE: ./components/home/header/styles.module.css
var header_styles_module = __webpack_require__(4803);
var header_styles_module_default = /*#__PURE__*/__webpack_require__.n(header_styles_module);
;// CONCATENATED MODULE: ./components/home/header/HeaderContentLeft.tsx








const HeaderContentLeft = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            position: 'relative',
            height: '260px',
            width: {
                md: '70%',
                lg: '80%',
                xl: '100%'
            }
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                className: (header_styles_module_default()).borderFadeIn,
                sx: headerTextLeftBorder
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                className: (header_styles_module_default()).borderFadeIn,
                sx: headerTextLeftBottomBorder
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                className: (header_styles_module_default()).borderFadeIn,
                sx: headerTextLeftTopBorder
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Title/* HeaderTitle */.Gh, {
                className: (header_styles_module_default()).animateLeftToRight,
                variant: "h5",
                children: "Welcome To Arcon Interior"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Title/* HeaderTitle */.Gh, {
                variant: "h2",
                className: (header_styles_module_default()).animateRightToLeft,
                sx: {
                    fontSize: {
                        xs: 30,
                        sm: 45,
                        md: 60
                    }
                },
                children: [
                    "Making Your Home ",
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                    }),
                    " More Beautiful"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    display: 'flex',
                    gap: 2,
                    alignItems: {
                        xs: 'center',
                        md: 'unset'
                    },
                    flexDirection: {
                        xs: 'column',
                        md: 'row'
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/projects",
                            passHref: true,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* OrangeBtn */.iI, {
                                className: (header_styles_module_default()).animateButton,
                                sx: {
                                    width: '200px'
                                },
                                children: "View More →"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        sx: {
                            display: {
                                xs: 'none',
                                sm: 'block'
                            }
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/about",
                            passHref: true,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* WhiteBtn */.ej, {
                                className: (header_styles_module_default()).animateButton,
                                sx: {
                                    width: '200px'
                                },
                                children: "Our Portfolio →"
                            })
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const header_HeaderContentLeft = (HeaderContentLeft);

;// CONCATENATED MODULE: ./components/home/header/HeaderContentRight.tsx









const HeaderContentRight = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            position: 'relative',
            height: '260px',
            width: {
                md: '70%',
                lg: '80%',
                xl: '100%'
            },
            textAlign: {
                sx: 'center',
                md: 'right'
            }
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: headerTextRightBorder
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: headerTextRightBottomBorder
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: headerTextRightTopBorder
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Title/* HeaderTitle */.Gh, {
                variant: "h2",
                className: (header_styles_module_default()).animateRightToLeft,
                sx: {
                    fontSize: {
                        xs: 30,
                        sm: 45,
                        md: 60
                    }
                },
                children: [
                    "Best Ideas For ",
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                    }),
                    " Your Home Interiors"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                className: (header_styles_module_default()).animateLeftToRight,
                sx: headerRightAdditionalInfo,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                        component: "div",
                        fontWeight: "700",
                        children: "10 Years Warranty"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                        component: "div",
                        sx: {
                            width: '2px',
                            height: {
                                sx: '16px',
                                md: '30px'
                            },
                            backgroundColor: constants/* SECONDARY_COLOR */.Vz
                        },
                        fontWeight: "700"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                        component: "div",
                        fontWeight: "700",
                        children: "Easy EMI"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                        component: "div",
                        sx: {
                            width: '2px',
                            height: {
                                sx: '16px',
                                md: '30px'
                            },
                            backgroundColor: constants/* SECONDARY_COLOR */.Vz
                        },
                        fontWeight: "700"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
                        component: "div",
                        fontWeight: "700",
                        children: "670+ Project Done"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    display: 'flex',
                    gap: 2,
                    mt: 2,
                    justifyContent: 'flex-end',
                    alignItems: {
                        xs: 'center',
                        md: 'unset'
                    },
                    flexDirection: {
                        xs: 'column',
                        md: 'row'
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/projects",
                            passHref: true,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* OrangeBtn */.iI, {
                                className: (header_styles_module_default()).animateButton,
                                sx: {
                                    width: '200px'
                                },
                                children: "View More →"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        sx: {
                            display: {
                                xs: 'none',
                                sm: 'block'
                            }
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/about",
                            passHref: true,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* WhiteBtn */.ej, {
                                className: (header_styles_module_default()).animateButton,
                                sx: {
                                    width: '200px'
                                },
                                children: "Our Portfolio →"
                            })
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const header_HeaderContentRight = (HeaderContentRight);

;// CONCATENATED MODULE: ./components/home/header/index.tsx








function Header() {
    const { 0: contentPosition , 1: setContentPosition  } = (0,external_react_.useState)('left');
    // this state determines whether the image is loaded or not
    const { 0: imageIsLoaded , 1: setImageIsLoaded  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        const interval = setInterval(()=>{
            if (contentPosition === 'left') {
                setContentPosition('right');
            } else {
                setContentPosition('left');
            }
        }, 10000);
        return ()=>clearInterval(interval)
        ;
    }, [
        contentPosition
    ]);
    const contentLeft = contentPosition === 'left';
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            height: {
                xs: '400px',
                sm: '600px',
                md: '700px'
            },
            position: 'relative',
            overflow: 'hidden',
            top: '-30px',
            background: 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5))'
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                className: (header_styles_module_default()).headerImage,
                src: contentLeft ? '/images/header-bg.jpg' : '/images/header-bg-2.jpg',
                layout: "fill",
                objectFit: "cover",
                objectPosition: "top",
                priority: true,
                alt: "Background Header Image",
                onLoadingComplete: ()=>{
                    setImageIsLoaded(true);
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ContactInfo, {
            }),
            imageIsLoaded && /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
                sx: {
                    textAlign: {
                        xs: 'center',
                        md: 'unset'
                    },
                    mt: {
                        xs: 19,
                        sm: 28
                    },
                    ml: {
                        md: 20
                    },
                    mx: {
                        xl: 'auto'
                    },
                    '@media screen and (max-width: 899px)': {
                        mx: 0
                    }
                },
                children: contentLeft ? /*#__PURE__*/ jsx_runtime_.jsx(header_HeaderContentLeft, {
                }) : /*#__PURE__*/ jsx_runtime_.jsx(header_HeaderContentRight, {
                })
            })
        ]
    }, contentPosition));
};

// EXTERNAL MODULE: external "@mui/icons-material/ArrowBackIos"
var ArrowBackIos_ = __webpack_require__(4195);
var ArrowBackIos_default = /*#__PURE__*/__webpack_require__.n(ArrowBackIos_);
// EXTERNAL MODULE: external "@mui/icons-material/ArrowForwardIos"
var ArrowForwardIos_ = __webpack_require__(1658);
var ArrowForwardIos_default = /*#__PURE__*/__webpack_require__.n(ArrowForwardIos_);
// EXTERNAL MODULE: ./components/common/project/styles.ts
var styles = __webpack_require__(3097);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: ./components/common/project/styles.module.css
var project_styles_module = __webpack_require__(3887);
var project_styles_module_default = /*#__PURE__*/__webpack_require__.n(project_styles_module);
;// CONCATENATED MODULE: ./components/home/projects/projectItems.tsx














function ProjectItems({ projects  }) {
    const arrowStyle = {
        color: constants/* SECONDARY_COLOR */.Vz,
        opacity: 0.6,
        '&:hover': {
            color: constants/* SECONDARY_COLOR */.Vz
        }
    };
    const settings = {
        infinite: false,
        speed: 500,
        slidesToShow: 3.2,
        slidesToScroll: 1,
        initialSlide: 0,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true
                }
            },
            {
                breakpoint: 990,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 620,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    prevArrow: /*#__PURE__*/ jsx_runtime_.jsx((ArrowBackIos_default()), {
                        sx: {
                            ...arrowStyle
                        }
                    }),
                    nextArrow: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {
                        sx: {
                            ...arrowStyle
                        }
                    })
                }
            }, 
        ]
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
            sx: {
                ml: {
                    md: 10,
                    xl: 40
                },
                overflow: 'hidden',
                px: {
                    xs: 4,
                    sm: 0
                }
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                ...settings,
                children: projects.map((project)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(styles/* ProjectContainer */.XR, {
                            className: (project_styles_module_default()).projectContainer,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    className: (project_styles_module_default()).projectImage,
                                    src: project.featureImg.url,
                                    alt: project.title,
                                    width: 500,
                                    height: 600,
                                    objectFit: "cover",
                                    placeholder: "blur",
                                    blurDataURL: "https://i.ibb.co/KV27zx8/skeleton.jpg"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                    className: (project_styles_module_default()).hoverOverlay,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(styles/* ProjectDetails */.ur, {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                            className: (project_styles_module_default()).detailsContainer,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: `/projects/${project._id}`,
                                                    passHref: true,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(styles/* ProjectName */.vV, {
                                                        variant: "h5",
                                                        children: project.title
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(styles/* ProjectDescription */.Wn, {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                                        sx: {
                                                            lineHeight: {
                                                                xs: 1.7,
                                                                xl: 2
                                                            },
                                                            fontSize: 'inherit'
                                                        },
                                                        component: "p",
                                                        children: [
                                                            project.description.substring(0, 150),
                                                            project.description.length < 150 ? ' ' : '...'
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                    sx: {
                                                        position: 'absolute',
                                                        bottom: '10px'
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                        href: `/projects/${project._id}`,
                                                        passHref: true,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* ProjectBtn */.Iz, {
                                                            children: "read more +"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    }, project._id)
                )
            })
        })
    }));
};

;// CONCATENATED MODULE: ./components/home/projects/index.tsx




function Projects({ projects  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    mt: 8
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Title/* SectionTitle */.NZ, {
                        sx: {
                            textAlign: 'center'
                        },
                        children: "Our Best Projects"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Title/* Title */.Dx, {
                        variant: "h4",
                        sx: {
                            fontSize: {
                                xs: 30,
                                sm: 40
                            },
                            px: 1,
                            mb: 6
                        },
                        children: [
                            "Lets Have A Look At What Creativity ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {
                            }),
                            " Best Projects"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ProjectItems, {
                projects: projects
            })
        ]
    }));
};

;// CONCATENATED MODULE: ./public/images/service1.png
/* harmony default export */ const service1 = ({"src":"/_next/static/media/service1.924f4c94.png","height":62,"width":144,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAHlBMVEX/cQD/bwD+bgD/bgD/bwD/bwAAChuQRQtQLRL/cgDXXDswAAAACnRSTlMtOgZyTmIrMxYWoHYugAAAAAlwSFlzAAALEwAACxMBAJqcGAAAACBJREFUCJkFwYcBADAIwzA70MH/DyOh8u8DbQbgVHWSLANpAD8VYDp8AAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/images/service2.png
/* harmony default export */ const service2 = ({"src":"/_next/static/media/service2.fa66778b.png","height":77,"width":183,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAHlBMVEUpJCF6PxH/fwAzIieBQxItGxoAAFGyUgcfISMXGhySZUGyAAAACnRSTlMpPhcMdxECHxpWUzTY4wAAAAlwSFlzAAALEwAACxMBAJqcGAAAACBJREFUCJlj4GBmZmFkY2VjYGThZGBlZGRnAAFmJiYmAATSAEqIluDTAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/images/service3.png
/* harmony default export */ const service3 = ({"src":"/_next/static/media/service3.139659a4.png","height":66,"width":175,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAJFBMVEUcGBUYFxc5GgAeDABMaXEMDAyCOgAZGRgAABNNIwBuMQCHPAALuf1OAAAADHRSTlMjG4NTACqVPBJ4x4DQQk1gAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIUlEQVQImQXBhw0AIAzAsKQLAf//W5u5H6wiozmtxEsRFgULAE3eaGucAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/images/service4.png
/* harmony default export */ const service4 = ({"src":"/_next/static/media/service4.855f96ea.png","height":78,"width":203,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAJFBMVEUaFhX8dQASDw/+cgD9bQBXMBgAABNlNhrWYx9jNRnRYR8hGhZF9ySJAAAADHRSTlMxEwYkOz4gYkJ0xRnhrAghAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIklEQVQImQXBiQEAMAgCsQO09tl/3yaYbisC70uqeMxZUj4ENQBZU96bqAAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/images/service5.png
/* harmony default export */ const service5 = ({"src":"/_next/static/media/service5.ec6d90c6.png","height":69,"width":217,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAFVBMVEUdGhckGx4ICxx/Pw1rOA9NLBIeGheNQl0cAAAAB3RSTlM0Bht/WWwWpYwamAAAAAlwSFlzAAALEwAACxMBAJqcGAAAABpJREFUCJljYGJlYWRkYGBkYGZmYGJjYGAAAAE0AB3gfwCWAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/home/serviceLogo/data.js










const data = [
    // {
    //     id: 1,
    //     image: logo1
    // },
    // {
    //     id: 1,
    //     image: logo2
    // },
    // {
    //     id: 1,
    //     image: logo3
    // },
    // {
    //     id: 1,
    //     image: logo4
    // },
    // {
    //     id: 1,
    //     image: logo5
    // },
    // {
    //     id: 1,
    //     image: logo6
    // },
    // {
    //     id: 1,
    //     image: logo7
    // },
    // {
    //     id: 1,
    //     image: logo8
    // },
    // {
    //     id: 1,
    //     image: logo9
    // },
    // {
    //     id: 1,
    //     image: logo10
    // },
    {
        id: 29,
        image: '/images/brand (1).jpg'
    },
    {
        id: 28,
        image: '/images/brand (2).jpg'
    },
    {
        id: 27,
        image: '/images/brand (3).jpg'
    },
    {
        id: 26,
        image: '/images/brand (4).jpg'
    },
    {
        id: 25,
        image: '/images/brand (5).jpg'
    },
    {
        id: 24,
        image: '/images/brand (6).jpg'
    },
    {
        id: 23,
        image: '/images/brand (7).jpg'
    },
    {
        id: 21,
        image: '/images/brand (8).jpg'
    },
    {
        id: 20,
        image: '/images/brand (9).jpg'
    },
    {
        id: 19,
        image: '/images/brand (10).jpg'
    },
    {
        id: 18,
        image: '/images/brand (11).jpg'
    },
    {
        id: 17,
        image: '/images/brand (12).jpg'
    },
    {
        id: 16,
        image: '/images/brand (13).jpg'
    },
    {
        id: 15,
        image: '/images/brand (14).jpg'
    },
    {
        id: 14,
        image: '/images/brand (15).jpg'
    },
    {
        id: 13,
        image: '/images/brand (16).jpg'
    },
    {
        id: 12,
        image: '/images/brand (17).jpg'
    },
    {
        id: 11,
        image: '/images/brand (18).jpg'
    },
    {
        id: 10,
        image: '/images/brand (19).jpg'
    },
    {
        id: 9,
        image: '/images/brand (20).jpg'
    },
    {
        id: 8,
        image: '/images/brand (21).jpg'
    },
    {
        id: 7,
        image: '/images/brand (22).jpg'
    },
    {
        id: 6,
        image: '/images/brand (23).jpg'
    },
    {
        id: 5,
        image: '/images/brand (24).jpg'
    },
    {
        id: 4,
        image: '/images/brand (25).jpg'
    },
    {
        id: 3,
        image: '/images/brand (26).jpg'
    },
    {
        id: 2,
        image: '/images/brand (27).jpg'
    },
    {
        id: 1,
        image: '/images/brand (28).jpg'
    }, 
];
/* harmony default export */ const serviceLogo_data = (data);

;// CONCATENATED MODULE: ./components/home/serviceLogo/index.tsx







function ServiceLogo() {
    var settings = {
        dots: false,
        infinite: true,
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: true,
        speed: 2000,
        autoplaySpeed: 2000,
        cssEase: 'linear',
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    initialSlide: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            }, 
        ]
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
        maxWidth: "xl",
        sx: {
            my: 5,
            overflow: 'hidden',
            px: '0 !important'
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
            ...settings,
            children: serviceLogo_data.map((logo)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        p: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                        src: logo.image,
                        alt: "logo",
                        width: 140,
                        height: 140,
                        objectFit: "contain"
                    })
                }, logo.id)
            )
        })
    }));
};

// EXTERNAL MODULE: ./components/home/services/index.tsx + 1 modules
var services = __webpack_require__(4978);
// EXTERNAL MODULE: ./components/home/testimonials/styles.module.css
var testimonials_styles_module = __webpack_require__(7202);
var testimonials_styles_module_default = /*#__PURE__*/__webpack_require__.n(testimonials_styles_module);
;// CONCATENATED MODULE: ./components/home/testimonials/data.js
const reviewData = [
    {
        id: 1,
        name: 'Dr. Wahidur Rahman',
        review: 'We were living Chittagong and planning on moving back into our home in the States and wanted to refresh the rooms. ARCON was the perfect blend of individualized service without having to meet in person or go to stores to find all items yourself. Designer Mr. Osman Goni & Mr. Arif had beautiful design ideas and was prompt to act on any preferences I suggested. Would highly recommend this service.',
        position: 'MBBS, FCPS, MEDICINE',
        img: '/images/wahid.png'
    },
    {
        id: 2,
        name: 'Lt. Col. M. Nezam Uddin',
        review: 'Thanks ARCON for great support on our project. They are not only showed their commitment and hard work in our project, but also helped us take care of some points that got missed by us and did not belong to their scope. It is a great help if the objective is in making the service successful, instead of just completing the project. The experience working with ARCON is great. Thanks and please keep on the same service and accountability!',
        position: '(Retd) Deputy Of Chittagong Port Authority',
        img: '/images/nezam.png'
    },
    {
        id: 3,
        name: 'Eng. Abdur Rahman',
        review: 'ARCON interior firm has a solid technology team and ontime delivery.. Very happy to be associated with them.',
        position: 'IT. HEAD OF THE DEPARTMENT .',
        img: '/images/abdur.png'
    },
    {
        id: 4,
        name: 'Dr. Farhana Chowdhury',
        review: 'Great work!!! The team was solid, efficient and knowledgeable. They did an amazing job in my project. I will be using them again. Thank you for doing such a great job!',
        position: 'FCPS, MBBS, BCS, Health',
        img: '/images/farhana.png'
    },
    {
        id: 5,
        name: 'Mrs . Sheeren Akter',
        review: '100% amazing and helpful ...highly recommended, VERY PROFESSIONAL”',
        position: 'Housewife, Owner - Epic Crown Ridge.',
        img: '/images/sheeren.png'
    }, 
];
/* harmony default export */ const testimonials_data = (reviewData);

;// CONCATENATED MODULE: ./components/home/testimonials/style.ts
const testimonialDesignation = {
    whiteSpace: "nowrap",
    width: {
        xs: "123px",
        lg: "100%"
    },
    overflow: "hidden",
    textOverflow: "ellipsis",
    fontSize: {
        xs: "10px",
        lg: "12px"
    }
};
const svgIcon = {
    position: 'absolute',
    right: '20px',
    bottom: '30px',
    display: {
        xs: "none",
        sm: "block"
    },
    width: {
        sm: "40px",
        md: '40px',
        lg: "50px"
    }
};

;// CONCATENATED MODULE: external "@mui/icons-material/FormatQuoteRounded"
const FormatQuoteRounded_namespaceObject = require("@mui/icons-material/FormatQuoteRounded");
var FormatQuoteRounded_default = /*#__PURE__*/__webpack_require__.n(FormatQuoteRounded_namespaceObject);
;// CONCATENATED MODULE: ./components/home/testimonials/index.tsx












function Testimonials() {
    const settings = {
        infinite: false,
        speed: 500,
        slidesToShow: 1.5,
        slidesToScroll: 1,
        initialSlide: 0,
        arrows: false,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 1.5,
                    slidesToScroll: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }, 
        ]
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        className: (testimonials_styles_module_default()).container,
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
            maxWidth: "xl",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                container: true,
                sx: {
                    alignItems: 'center',
                    my: 14
                },
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 4,
                        xs: 12,
                        sm: 12,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                            sx: {
                                ml: {
                                    xs: 3,
                                    md: 10
                                }
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Title/* SectionTitle */.NZ, {
                                    children: "Testimonials"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Title/* HeaderTitle */.Gh, {
                                    variant: "h3",
                                    sx: {
                                        fontSize: {
                                            xs: 30,
                                            sm: 40
                                        }
                                    },
                                    children: "What They’re Talking About Company Work"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* WhiteBtn */.ej, {
                                    children: "View More →"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        md: 8,
                        xs: 12,
                        sm: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                            ...settings,
                            children: testimonials_data.map((review)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                        className: (testimonials_styles_module_default()).reviewCard,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                className: (testimonials_styles_module_default()).avatarContainer,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                    className: (testimonials_styles_module_default()).avatar,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                        src: review.img,
                                                        width: 106,
                                                        height: 106,
                                                        alt: "",
                                                        className: (testimonials_styles_module_default()).img
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                className: (testimonials_styles_module_default()).content,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                        sx: svgIcon,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormatQuoteRounded_default()), {
                                                            color: 'secondary',
                                                            sx: {
                                                                fontSize: 50
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                        sx: {
                                                            pb: 5,
                                                            height: '220px',
                                                            overflow: 'hidden',
                                                            mb: 2,
                                                            textOverflow: 'ellipsis'
                                                        },
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                                            component: "blockquote",
                                                            sx: {
                                                                lineHeight: {
                                                                    xs: 1.5,
                                                                    md: '36px'
                                                                },
                                                                fontWeight: 400,
                                                                fontSize: {
                                                                    xs: 16,
                                                                    sm: 18
                                                                },
                                                                color: 'rgba(255,255,255,.8)',
                                                                fontStyle: 'italic'
                                                            },
                                                            children: [
                                                                "\" ",
                                                                review.review,
                                                                "\""
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                                color: "secondary",
                                                                variant: "h6",
                                                                sx: {
                                                                    fontSize: {
                                                                        xs: 13,
                                                                        lg: 18
                                                                    }
                                                                },
                                                                children: review.name
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                                sx: testimonialDesignation,
                                                                variant: "body2",
                                                                children: review.position
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, review.id)
                            )
                        })
                    })
                ]
            })
        })
    }));
};

;// CONCATENATED MODULE: external "@mui/material/Divider"
const Divider_namespaceObject = require("@mui/material/Divider");
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/House"
const House_namespaceObject = require("@mui/icons-material/House");
var House_default = /*#__PURE__*/__webpack_require__.n(House_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/AccessTime"
const AccessTime_namespaceObject = require("@mui/icons-material/AccessTime");
var AccessTime_default = /*#__PURE__*/__webpack_require__.n(AccessTime_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Streetview"
const Streetview_namespaceObject = require("@mui/icons-material/Streetview");
var Streetview_default = /*#__PURE__*/__webpack_require__.n(Streetview_namespaceObject);
;// CONCATENATED MODULE: ./components/home/whyArcon/data.js




const iconProps = {
    fontSize: '70px',
    color: 'white',
    border: '1px solid white',
    padding: '14px',
    marginRight: '10px'
};
const ArconData = [
    {
        id: 1,
        title: 'We Are Pofessional',
        description: 'We develop a full cycle of conry to Loream project documentation.',
        icon: /*#__PURE__*/ jsx_runtime_.jsx((House_default()), {
            sx: {
                ...iconProps
            }
        })
    },
    {
        id: 2,
        title: 'Honest and Dependable',
        description: 'Our experience and commitment to our customers assure will meet your objectives.',
        icon: /*#__PURE__*/ jsx_runtime_.jsx((AccessTime_default()), {
            sx: {
                ...iconProps
            }
        })
    },
    {
        id: 3,
        title: 'Energy Saving Mathods',
        description: 'Part of experts team to manage commercial and institutional projects.',
        icon: /*#__PURE__*/ jsx_runtime_.jsx((Streetview_default()), {
            sx: {
                ...iconProps
            }
        })
    }, 
];
/* harmony default export */ const whyArcon_data = (ArconData);

// EXTERNAL MODULE: ./components/home/whyArcon/styles.module.css
var whyArcon_styles_module = __webpack_require__(9396);
var whyArcon_styles_module_default = /*#__PURE__*/__webpack_require__.n(whyArcon_styles_module);
;// CONCATENATED MODULE: ./components/home/whyArcon/index.tsx








function WhyArcon() {
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
        maxWidth: "xl",
        sx: {
            p: {
                xs: 0,
                sm: 0
            }
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
            container: true,
            spacing: 4,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    className: (whyArcon_styles_module_default()).aboutArcon,
                    item: true,
                    md: 5,
                    sm: 12,
                    xs: 12,
                    sx: {
                        backgroundColor: constants/* TERTIARY_COLOR */.AX
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        children: whyArcon_data.map((data)=>{
                            return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                sx: {
                                    px: 2
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                        sx: {
                                            display: 'flex',
                                            p: 3,
                                            alignItems: 'center'
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                children: data.icon
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        variant: "h6",
                                                        sx: {
                                                            fontWeight: '700'
                                                        },
                                                        children: data.title
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        variant: "body2",
                                                        children: data.description
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    (data === null || data === void 0 ? void 0 : data.id) == 1 || (data === null || data === void 0 ? void 0 : data.id) == 2 ? /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                                        sx: {
                                            bgcolor: '#ffd700'
                                        }
                                    }) : ''
                                ]
                            }, data.id));
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    md: 7,
                    sm: 12,
                    xs: 12,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
                        sx: {
                            mx: 'auto'
                        },
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            container: true,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                    item: true,
                                    md: 12,
                                    sm: 12,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* SectionTitle */.NZ, {
                                            children: "Why Arcon"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                            fontWeight: "700",
                                            variant: "h4",
                                            sx: {
                                                fontSize: {
                                                    xs: 30,
                                                    sm: 40
                                                }
                                            },
                                            children: "Interior Designs From The Future Living Styles"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Title/* Description */.dk, {
                                            sx: {
                                                my: 2,
                                                pr: 4
                                            },
                                            children: "There are certain attributes of a profession and one has to catch hold of them in order to work efficiently and grow in that business. I share my experience as an interior designer, a profession of great esthetic value and charm."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                    item: true,
                                    md: 12,
                                    sm: 8,
                                    sx: {
                                        mx: 'auto'
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                        src: "/images/arcon.jpg",
                                        alt: "Picture of the author",
                                        width: 800,
                                        height: 400,
                                        objectFit: "cover",
                                        loading: "lazy"
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};

// EXTERNAL MODULE: ./components/home/workingStyle/styles.module.css
var workingStyle_styles_module = __webpack_require__(3098);
var workingStyle_styles_module_default = /*#__PURE__*/__webpack_require__.n(workingStyle_styles_module);
;// CONCATENATED MODULE: ./public/images/work1.jpg
/* harmony default export */ const work1 = ({"src":"/_next/static/media/work1.b11a09d5.jpg","height":720,"width":960,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAbEAACAwADAAAAAAAAAAAAAAABAgADBBExQf/EABQBAQAAAAAAAAAAAAAAAAAAAAP/xAAWEQEBAQAAAAAAAAAAAAAAAAAAAjH/2gAMAwEAAhEDEQA/AJ9lmt8dSrpKVEDlAO/QIiINGnH/2Q=="});
;// CONCATENATED MODULE: ./public/images/work2.jpg
/* harmony default export */ const work2 = ({"src":"/_next/static/media/work2.5af38707.jpg","height":720,"width":960,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAdEAACAgIDAQAAAAAAAAAAAAABAgAEA1EGEyFh/8QAFQEBAQAAAAAAAAAAAAAAAAAAAwT/xAAXEQADAQAAAAAAAAAAAAAAAAAAAQIh/9oADAMBAAIRAxEAPwCDT5Bns3MVQOw6ncMpAKsFHv3WoiIFPSiVh//Z"});
;// CONCATENATED MODULE: ./public/images/work3.jpg
/* harmony default export */ const work3 = ({"src":"/_next/static/media/work3.d52ae8aa.jpg","height":540,"width":960,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAFAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAP/xAAgEAAABgEFAQAAAAAAAAAAAAAAAQIDBBEFEhMhIjFh/8QAFQEBAQAAAAAAAAAAAAAAAAAAAwT/xAAWEQEBAQAAAAAAAAAAAAAAAAAAARH/2gAMAwEAAhEDEQA/ALHnskrFJjFLcS8T+ycm+58arv35VgACa3Dv/9k="});
;// CONCATENATED MODULE: ./components/home/workingStyle/data.js



const workingStyles = [
    {
        id: 1,
        title: 'Innovative Wall Decorotion',
        description: 'Commodo fugiat irure enim enim in qui consequat mollit nisi laborum elit.',
        image: work1,
        bgSerial: '01'
    },
    {
        id: 2,
        title: 'Quality Interior Decoration',
        description: 'Commodo fugiat irure enim enim in qui consequat mollit nisi laborum elit.',
        image: work2,
        bgSerial: '02'
    },
    {
        id: 3,
        title: 'A High Interior Architecture',
        description: 'Commodo fugiat irure enim enim in qui consequat mollit nisi laborum elit.',
        image: work3,
        bgSerial: '03'
    }, 
];
/* harmony default export */ const workingStyle_data = (workingStyles);

;// CONCATENATED MODULE: ./components/home/workingStyle/index.tsx







function WorkingStyle() {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    my: 5,
                    textAlign: 'center'
                },
                component: "div",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Title/* SectionTitle */.NZ, {
                        children: "Working Style"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Title/* Title */.Dx, {
                        variant: "h4",
                        sx: {
                            fontSize: {
                                xs: 30,
                                sm: 40
                            }
                        },
                        children: [
                            "Our Innovative Ideas, The Most Stylish",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {
                            }),
                            " Working Style"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    position: 'relative',
                    mt: 12,
                    zIndex: 1,
                    background: 'white',
                    boxShadow: 5,
                    py: 2
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    container: true,
                    spacing: 6,
                    justifyContent: "center",
                    position: "relative",
                    top: "-80px",
                    children: workingStyle_data.map((work)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            item: true,
                            className: (workingStyle_styles_module_default()).singleWork,
                            md: 3,
                            sm: 12,
                            xs: 12,
                            sx: {
                                justifyContent: 'center',
                                textAlign: 'center',
                                m: 1
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: work.image,
                                    alt: work.title,
                                    width: 120,
                                    height: 120,
                                    className: (workingStyle_styles_module_default()).image
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    variant: "h6",
                                    fontWeight: "600",
                                    children: work.title
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Title/* Description */.dk, {
                                    children: work.description
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* ReadMoreBtn */.YV, {
                                    children: "Read More"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                    className: (workingStyle_styles_module_default()).serial,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        variant: "h1",
                                        fontWeight: "700",
                                        color: "#efefef",
                                        children: work.bgSerial
                                    })
                                })
                            ]
                        }, work.id)
                    )
                })
            })
        ]
    }));
};

;// CONCATENATED MODULE: ./pages/index.tsx















const Home = ({ projects  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Arcon Interior"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(navbar/* default */.Z, {
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Header, {
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(AboutArcon, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(services/* default */.Z, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Projects, {
                        projects: projects
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(WorkingStyle, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Testimonials, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(WhyArcon, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ServiceLogo, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Contact, {
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {
            })
        ]
    }));
};
const getServerSideProps = async ()=>{
    const projects = await (0,backend_projects/* getProjects */.mW)();
    return {
        props: {
            projects
        }
    };
};
/* harmony default export */ const pages = (Home);


/***/ }),

/***/ 7915:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material");

/***/ }),

/***/ 7541:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/AccessTimeFilled");

/***/ }),

/***/ 6224:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Apartment");

/***/ }),

/***/ 9711:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ArchitectureOutlined");

/***/ }),

/***/ 4195:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ArrowBackIos");

/***/ }),

/***/ 1658:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ArrowForwardIos");

/***/ }),

/***/ 7533:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/BusinessOutlined");

/***/ }),

/***/ 2081:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Call");

/***/ }),

/***/ 4173:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 3188:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 9524:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/DoorSlidingOutlined");

/***/ }),

/***/ 9226:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Email");

/***/ }),

/***/ 7666:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 8139:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/HouseSiding");

/***/ }),

/***/ 5167:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Houseboat");

/***/ }),

/***/ 3281:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 9881:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 5939:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LinkedIn");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/PhoneInTalkOutlined");

/***/ }),

/***/ 5941:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Pinterest");

/***/ }),

/***/ 3455:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/WindowOutlined");

/***/ }),

/***/ 6072:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/lab");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4960:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 8611:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Dialog");

/***/ }),

/***/ 9404:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/DialogActions");

/***/ }),

/***/ 1094:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/DialogContent");

/***/ }),

/***/ 2468:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/DialogTitle");

/***/ }),

/***/ 3661:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Fab");

/***/ }),

/***/ 7934:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 5768:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Popover");

/***/ }),

/***/ 1528:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Zoom");

/***/ }),

/***/ 5574:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/colors");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 4156:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/useScrollTrigger");

/***/ }),

/***/ 7986:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 2296:
/***/ ((module) => {

"use strict";
module.exports = require("formik");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 8096:
/***/ ((module) => {

"use strict";
module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,664,133,780,36,847,978], () => (__webpack_exec__(3737)));
module.exports = __webpack_exports__;

})();